// Unwip - main process: windows, files, clipboard, fonts, backups, PDF export.
const { app, BrowserWindow, ipcMain, clipboard, nativeImage, dialog, shell, session, Menu, screen } = require('electron');
// the optional natural voice (downloaded only when asked for): app/voice/voice-main.js
const voiceSetup = require('./app/voice/voice-main.js');
const path = require('path');
const fs = require('fs');
// Unwip Dev: a separate copy for trying new versions before everyone gets them. A Dev build's package.json says
// "flavor": "dev"; it then has its own name, settings, library and synced folders ("Unwip Dev" instead of "Unwip"),
// and its own update feed, so nothing it does can touch the real books or the real app.
const FLAVOR = (() => { try { return JSON.parse(fs.readFileSync(path.join(__dirname, 'package.json'), 'utf8')).flavor === 'dev' ? 'dev' : 'stable'; } catch { return 'stable'; } })();
const DEV = FLAVOR === 'dev', FOLDER = DEV ? 'Unwip Dev' : 'Unwip', APP_NAME = DEV ? 'Unwip Dev' : 'Unwip';
if (DEV) app.setName(APP_NAME);

// Projects live in Documents\Unwip. Earlier versions (named Folio) used Documents\Folio, so move that across once.
let libraryPath = null;
// The library can also live in a synced folder (Dropbox, OneDrive…), chosen in Settings. That choice is kept in settings.json.
let libraryOverride = undefined;
const LIBRARY = () => {
  if (libraryOverride === undefined) { try { const s = JSON.parse(fs.readFileSync(path.join(app.getPath('userData'), 'settings.json'), 'utf8')); libraryOverride = s.libraryPath || null; } catch { libraryOverride = null; } }
  if (libraryOverride) followFlattenedDropbox();
  return libraryOverride || libraryPath || path.join(app.getPath('documents'), FOLDER);
};
// Dropbox/Apps/Unwip/Unwip became Dropbox/Apps/Unwip (the phone moves the books up one level, Dropbox carries the
// move to this PC). Once the old folder has no projects left and the new one has them, follow them there.
let flattenCheckedAt = 0;
function followFlattenedDropbox() {
  if (Date.now() - flattenCheckedAt < 5000) return; flattenCheckedAt = Date.now();
  const lib = libraryOverride, parent = path.dirname(lib);
  if (!/unwip$/i.test(path.basename(lib)) || !/unwip$/i.test(path.basename(parent)) || !/^apps$/i.test(path.basename(path.dirname(parent)))) return;
  const projects = d => { try { return fs.readdirSync(d, { withFileTypes: true }).filter(x => x.isDirectory() && fs.existsSync(path.join(d, x.name, 'project.json'))).length; } catch { return 0; } };
  if (projects(lib) === 0 && projects(parent) > 0) {
    try { const f = path.join(app.getPath('userData'), 'settings.json'); const st = JSON.parse(fs.readFileSync(f, 'utf8')); st.libraryPath = parent; fs.writeFileSync(f, JSON.stringify(st, null, 2)); } catch {}
    libraryOverride = parent;
    try { fs.rmdirSync(lib); } catch {}     // only if it's empty
  }
}
const DEFAULT_LIBRARY = () => libraryPath || path.join(app.getPath('documents'), FOLDER);
const FONT_DIR = () => path.join(app.getPath('userData'), 'fonts');
const MAX_BACKUPS = 20;
// which automatic backups to remove: the newest 20 are kept, and of anything older, the last one of each day for
// two weeks, so a long writing day can't push out every copy from yesterday and before
function backupsToPrune(all) {
  const sorted = [...all].sort(), keep = new Set(sorted.slice(-MAX_BACKUPS)), days = new Set();
  for (const f of sorted.slice(0, -MAX_BACKUPS).reverse()) { const d = f.slice(0, 10); if (!days.has(d) && days.size < 14) { days.add(d); keep.add(f); } }
  return sorted.filter(f => !keep.has(f));
}
const OFFSCREEN = process.env.FOLIO_OFFSCREEN === '1'; // only used by automated tests

// One-time move from the old name. If a folder is in use and can't be renamed, keep using the old one.
(function migrateFromFolio() {
  if (OFFSCREEN) return;
  if (DEV) { try { app.setPath('userData', path.join(app.getPath('appData'), FOLDER)); } catch {} return; }
  try {
    const docs = app.getPath('documents');
    const oldLib = path.join(docs, 'Folio'), newLib = path.join(docs, 'Unwip');
    if (fs.existsSync(oldLib) && !fs.existsSync(newLib)) {
      try { fs.renameSync(oldLib, newLib); } catch { libraryPath = oldLib; }
    }
    const appData = app.getPath('appData');
    const oldUD = path.join(appData, 'Folio'), newUD = path.join(appData, 'Unwip');
    if (fs.existsSync(oldUD) && !fs.existsSync(newUD)) {
      try { fs.renameSync(oldUD, newUD); app.setPath('userData', newUD); } catch { app.setPath('userData', oldUD); }
    } else app.setPath('userData', newUD);
  } catch {}
})();

let win;

// Windows: paths over 260 characters need the \\?\ form (a deep binder exported into a deep Dropbox folder
// can get there), and some names can't be files at all ("CON", "NUL", "COM1"…, or a name ending in a dot)
const LP = p => (process.platform === 'win32' && p && p.length >= 240 && !String(p).startsWith('\\\\?\\')) ? (String(p).startsWith('\\\\') ? '\\\\?\\UNC\\' + path.resolve(p).slice(2) : '\\\\?\\' + path.resolve(p)) : p;
const winName = n => { n = String(n).replace(/[. ]+$/, '').trim() || 'Untitled'; return /^(con|prn|aux|nul|com[0-9]|lpt[0-9])(\.|$)/i.test(n) ? '_' + n : n; };
function ensureDir(p) { fs.mkdirSync(LP(p), { recursive: true }); return p; }
function readJSON(p, fallback) { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return fallback; } }
// remembers a fingerprint of every file Unwip writes, so changes made by another device (via Dropbox) can be told apart
const written = new Map();
const fingerprint = data => require('crypto').createHash('sha1').update(data).digest('hex');
function writeFileSafe(p, data) {
  // write to a temp file then rename, so a crash mid-save never corrupts the original
  const tmp = p + '.tmp';
  written.set(path.resolve(p), fingerprint(data));
  // flushed to the disk before the swap, so a power cut can't leave an empty file in place of the old one
  const fd = fs.openSync(LP(tmp), 'w');
  try { fs.writeSync(fd, typeof data === 'string' ? data : Buffer.from(data)); try { fs.fsyncSync(fd); } catch {} } finally { fs.closeSync(fd); }
  swapIn(LP(tmp), LP(p));
}
// On Windows, Dropbox, OneDrive or a virus checker can hold a file open for a moment while it reads it, and then
// swapping the new version in fails ("EPERM", "EBUSY"). Wait a little and try again; as a last resort, copy the new
// version over the old one (the finished new version is safely on disk either way).
const BUSY = /^(EPERM|EBUSY|EACCES)$/;
function swapIn(tmp, p) {
  for (let i = 0; ; i++) {
    try { fs.renameSync(tmp, p); return; }
    catch (e) {
      if (!BUSY.test(e.code)) throw e;
      if (i >= 8) { fs.copyFileSync(tmp, p); try { fs.unlinkSync(tmp); } catch {} return; }
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 40 * (i + 1));   // 40 ms, 80 ms, … about 1.4 s in all
    }
  }
}
// Saving over a version this computer has never seen (another device's change that arrived a moment ago, before
// Unwip noticed it) would lose that change without a trace. So that version is kept first as a "conflicted copy",
// the same way Dropbox does it, and the "Two versions found" window offers it. Nothing is lost.
const seen = (p, data) => { try { written.set(path.resolve(p), fingerprint(data)); } catch {} };
function guardedWrite(slug, p, data) {
  const full = path.resolve(p);
  try {
    if (written.has(full) && fs.existsSync(full)) {
      const disk = fs.readFileSync(full), fp = fingerprint(disk);
      if (fp !== written.get(full) && fp !== fingerprint(data)) {
        const ext = path.extname(full), base = full.slice(0, -ext.length), day = new Date().toISOString().slice(0, 10);
        let c = `${base} (another device's conflicted copy ${day})${ext}`, n = 2;
        while (fs.existsSync(c)) c = `${base} (another device's conflicted copy ${day} ${n++})${ext}`;
        fs.writeFileSync(c, disk);
        setTimeout(() => { if (win && !win.isDestroyed()) win.webContents.send('project:external', { slug, file: 'conflict', id: null }); }, 300);
      }
    }
  } catch {}
  writeFileSafe(p, data);
}
function slugify(name) {
  // a book's folder name: no characters Windows can't use, no name Windows reserves ("CON"), and nothing at the start
  // that Unwip uses for its own folders (_Deleted) or for books kept elsewhere (@…~)
  let n = (name || 'Untitled').replace(/[<>:"/\\|?*\x00-\x1F]/g, '').trim().replace(/^[_@~.\s]+/, '').slice(0, 60).replace(/[. ]+$/, '').trim() || 'Untitled';
  if (/^(con|prn|aux|nul|com[0-9]|lpt[0-9])(\.|$)/i.test(n)) n += ' book';
  return n;
}
// A book normally lives in the library folder. It can also be made somewhere else (a book kept on this PC only while
// the library is in Dropbox, say); those folders are remembered in settings.bookPlaces, and such a book's name inside
// Unwip starts with @ and a short code for its folder: "@1a2b3c~My Book".
const same = (a, b) => path.resolve(a).toLowerCase() === path.resolve(b).toLowerCase();
const placeKey = p => require('crypto').createHash('sha1').update(path.resolve(p).toLowerCase()).digest('hex').slice(0, 6);
let placesCache = null;
function extraPlaces() {
  if (!placesCache) placesCache = (loadSettings().bookPlaces || []).filter(p => typeof p === 'string' && path.isAbsolute(p));
  return placesCache.filter(p => !same(p, LIBRARY()));
}
function placeOf(slug) {
  const m = /^@([0-9a-f]{6})~(.+)$/.exec(String(slug));
  if (!m) return { root: LIBRARY(), folder: String(slug) };
  const root = extraPlaces().find(p => placeKey(p) === m[1]);
  if (!root) throw new Error(`This book’s folder isn’t known on ${MAC ? 'this Mac' : 'this PC'}.`);
  return { root, folder: m[2] };
}
const slugFor = (root, folder) => same(root, LIBRARY()) ? folder : `@${placeKey(root)}~${folder}`;
// On a Mac the same app, with a Mac's words and places
const MAC = process.platform === 'darwin';
const HERE = MAC ? 'This Mac' : 'This PC';
function projectDir(slug) {
  const { root, folder } = placeOf(slug);
  if (/[\\/]/.test(folder) || folder === '..' || folder === '.') throw new Error('Bad project path');
  const dir = path.resolve(root, folder);
  if (!dir.startsWith(path.resolve(root))) throw new Error('Bad project path');
  return dir;
}
// for grouping books on the main screen: Dropbox first, then other synced folders, then other folders, this PC last
function placeRank(p) { const l = placeLabel(p); return l === 'Dropbox' ? 0 : ['OneDrive', 'Google Drive', 'iCloud Drive'].includes(l) ? 1 : l === HERE ? 3 : 2; }
// in plain words, where a folder is
function placeLabel(p) {
  if (same(p, DEFAULT_LIBRARY())) return HERE;
  if (/[\\/]Dropbox[\\/]/i.test(p + path.sep) || /dropbox/i.test(path.dirname(p))) return 'Dropbox';
  if (/onedrive/i.test(p)) return 'OneDrive';
  if (/google drive|googledrive|my drive/i.test(p)) return 'Google Drive';
  if (/icloud|Mobile Documents/i.test(p)) return 'iCloud Drive';
  return path.basename(path.dirname(p)) + path.sep + path.basename(p);
}
function safeId(id) { return String(id).replace(/[^a-zA-Z0-9_-]/g, ''); }

function createWindow() {
  win = new BrowserWindow({
    width: 1400, height: 900, minWidth: 900, minHeight: 600,
    backgroundColor: '#f7f5f0',
    title: APP_NAME,
    icon: path.join(__dirname, 'app', process.platform === 'win32' ? 'icon.ico' : 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: true,
      offscreen: OFFSCREEN
    }
  });
  taskbarDetails(win);
  // a Mac needs its menu bar for Cmd+C, Cmd+V, Cmd+Z and Cmd+Q to work at all; Windows gets none (Unwip has its own)
  if (MAC) {
    app.setAboutPanelOptions({ applicationName: APP_NAME, applicationVersion: APP_VERSION(), credits: 'Write to finish' });
    Menu.setApplicationMenu(Menu.buildFromTemplate([
      { role: 'appMenu' },
      // the standard Edit menu, plus Cmd+Shift+V for Paste matching manuscript style (the Google Docs key for plain paste)
      { label: 'Edit', submenu: [{ role: 'undo' }, { role: 'redo' }, { type: 'separator' }, { role: 'cut' }, { role: 'copy' }, { role: 'paste' },
        { label: 'Paste Matching Manuscript Style', accelerator: 'Cmd+Shift+V', click: () => win.webContents.send('paste-plain') },
        { role: 'delete' }, { role: 'selectAll' }, { type: 'separator' },
        { label: 'Speech', submenu: [{ role: 'startSpeaking' }, { role: 'stopSpeaking' }] }] },
      { label: 'View', submenu: [{ role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { type: 'separator' }, { role: 'togglefullscreen' }] },
      { role: 'windowMenu' }
    ]));
  } else Menu.setApplicationMenu(null);
  guardClose(win);
  win.loadFile(path.join(__dirname, 'app', 'index.html'));

  // Spellcheck suggestions on right-click inside the editor
  // Right-click menu in text areas: spelling, cut/copy/paste, and a clipboard check for troubleshooting
  win.webContents.on('context-menu', (_e, params) => {
    if (!params.isEditable) return;
    const picked = String(params.selectionText || '').trim();
    const items = [];
    if (params.misspelledWord) {
      for (const s of params.dictionarySuggestions.slice(0, 6)) items.push({ label: s, click: () => win.webContents.replaceMisspelling(s) });
      if (!items.length) items.push({ label: 'No suggestions', enabled: false });
      items.push({ label: `Add "${params.misspelledWord}" to dictionary`, click: () => win.webContents.session.addWordToSpellCheckerDictionary(params.misspelledWord) });
      if (params.dictionarySuggestions.length) items.push({ label: 'Always correct to', submenu: params.dictionarySuggestions.slice(0, 6).map(s => ({ label: s, click: () => { win.webContents.replaceMisspelling(s); win.webContents.send('autocorrect-add', { from: params.misspelledWord, to: s }); } })) });
      items.push({ type: 'separator' });
    }
    items.push({ label: 'Cut', role: 'cut', enabled: params.editFlags.canCut });
    items.push({ label: 'Copy', role: 'copy', enabled: params.editFlags.canCopy });
    items.push({ label: 'Paste', role: 'paste', enabled: params.editFlags.canPaste });
    items.push({ label: 'Paste matching manuscript style', enabled: params.editFlags.canPaste, click: () => win.webContents.send('paste-plain') });
    items.push({ type: 'separator' });
    items.push({ label: 'Add comment   (Ctrl+Alt+M)', click: () => win.webContents.send('note-cmd', 'comment') });
    items.push({ label: 'Insert footnote   (Ctrl+Alt+F)', click: () => win.webContents.send('note-cmd', 'footnote') });
    // Detail and Lore: selected words can go onto a character, place or thing page, or start a timeline event; at Lore also
    // a character's sheet (an item name, or a whole [Item Obtained: …] line) or the Story Bible (addto.js does the work)
    if (uiLevel >= 1 && picked) {
      const to = kind => () => win.webContents.send('add-to', { kind, text: picked.slice(0, 2000) });
      const sub = [{ label: 'A character, place or thing page…', click: to('page') }, { label: 'A new timeline event…', click: to('event') }];
      if (uiLevel >= 2) sub.push({ type: 'separator' }, { label: 'A character sheet (gear)…', click: to('sheet') }, { label: 'The Story Bible…', click: to('bible') });
      items.push({ label: 'Add to', submenu: sub });
    }
    items.push({ type: 'separator' });
    items.push({ label: 'Insert picture…', click: () => win.webContents.send('note-cmd', 'image') });
    items.push({ label: 'Split document here   (Ctrl+Shift+K)', click: () => win.webContents.send('split-here') });
    items.push({ type: 'separator' });
    items.push({ label: 'Clipboard check (troubleshooting)…', click: clipboardCheck });
    Menu.buildFromTemplate(items).popup();
  });

  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  win.on('closed', () => { for (const w of popouts.values()) closePopout(w); for (const w of buildWins.values()) closePopout(w); });
}

// ---------- A chapter in its own window (for a second screen) ----------
// The chapter is edited only there while it's open: the main window shows it as "open in its own window", gets
// its word count as it changes, and closes it (saved) when the book is closed.
const popouts = new Map();   // "slug|id" -> window
const popKey = (slug, id) => `${slug}|${id}`;
function tellMain(ch, data) { if (win && !win.isDestroyed()) win.webContents.send(ch, data); }
async function closePopout(w) {
  if (!w || w.isDestroyed()) return;
  try { await Promise.race([w.webContents.executeJavaScript('window.__flush ? window.__flush() : 1'), new Promise(r => setTimeout(r, 3000))]); } catch {}
  // words it still couldn't save go to the main window, which keeps them and keeps trying (with the "Not saved" bar),
  // instead of closing the window on them
  try { const left = await Promise.race([w.webContents.executeJavaScript('window.__unsaved ? window.__unsaved() : null'), new Promise(r => setTimeout(() => r(null), 1500))]); if (left && w.__slug) tellMain('popout:unsaved', { slug: w.__slug, id: w.__id, html: left }); } catch {}
  w.__saved = true; if (!w.isDestroyed()) w.destroy();
}
ipcMain.handle('popout:open', (_e, slug, id, title) => {
  const k = popKey(slug, id);
  if (popouts.has(k) && !popouts.get(k).isDestroyed()) { const w = popouts.get(k); if (w.isMinimized()) w.restore(); w.focus(); return true; }
  // an ordinary window on the same screen as the main one (about half its width), each new one a little further along,
  // so several can sit side by side on one monitor or be dragged to another
  const area = (win ? screen.getDisplayMatching(win.getBounds()) : screen.getPrimaryDisplay()).workArea;
  const n = [...popouts.values()].filter(x => !x.isDestroyed()).length;
  const width = Math.max(480, Math.min(820, Math.round(area.width / 2))), height = Math.max(500, area.height - 80);
  const x = area.x + area.width - width - 20 - (n % 6) * 40, y = area.y + 30 + (n % 6) * 30;
  const w = new BrowserWindow({
    width, height, x: Math.max(area.x, x), y, minWidth: 420, minHeight: 400,
    backgroundColor: '#f7f5f0', title: (title || 'Chapter') + ' — Unwip', autoHideMenuBar: true,
    icon: path.join(__dirname, 'app', process.platform === 'win32' ? 'icon.ico' : 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, spellcheck: true, offscreen: OFFSCREEN }
  });
  popouts.set(k, w); taskbarDetails(w);
  w.loadFile(path.join(__dirname, 'app', 'popout.html'), { query: { slug: String(slug), id: String(id) } });
  w.webContents.on('context-menu', (_e2, params) => {
    if (!params.isEditable) return;
    const items = [];
    if (params.misspelledWord) {
      for (const sug of params.dictionarySuggestions.slice(0, 6)) items.push({ label: sug, click: () => w.webContents.replaceMisspelling(sug) });
      if (!items.length) items.push({ label: 'No suggestions', enabled: false });
      items.push({ label: `Add "${params.misspelledWord}" to dictionary`, click: () => w.webContents.session.addWordToSpellCheckerDictionary(params.misspelledWord) });
      if (params.dictionarySuggestions.length && win && !win.isDestroyed()) items.push({ label: 'Always correct to', submenu: params.dictionarySuggestions.slice(0, 6).map(s => ({ label: s, click: () => { w.webContents.replaceMisspelling(s); win.webContents.send('autocorrect-add', { from: params.misspelledWord, to: s }); } })) });
      items.push({ type: 'separator' });
    }
    items.push({ label: 'Cut', role: 'cut', enabled: params.editFlags.canCut }, { label: 'Copy', role: 'copy', enabled: params.editFlags.canCopy }, { label: 'Paste', role: 'paste', enabled: params.editFlags.canPaste });
    Menu.buildFromTemplate(items).popup();
  });
  w.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  // closing it saves first
  w.__slug = slug; w.__id = id;
  w.on('close', e => { if (w.__saved) return; e.preventDefault(); closePopout(w); });
  w.on('closed', () => { if (popouts.get(k) === w) popouts.delete(k); tellMain('popout:changed', { slug, id, open: false }); });
  tellMain('popout:changed', { slug, id, open: true });
  return true;
});
// Build in its own window (from inside a book): the whole app, showing just that piece; closing it saves first
const buildWins = new Map();
ipcMain.handle('build:window', (_e, id, title) => {
  id = String(id || ''); if (!/^[\w-]+$/.test(id)) return false;
  const old = buildWins.get(id); if (old && !old.isDestroyed()) { if (old.isMinimized()) old.restore(); old.focus(); return true; }
  const area = (win ? screen.getDisplayMatching(win.getBounds()) : screen.getPrimaryDisplay()).workArea;
  const width = Math.max(560, Math.min(980, Math.round(area.width * 0.55))), height = Math.max(520, area.height - 80);
  const w = new BrowserWindow({
    width, height, x: area.x + area.width - width - 20, y: area.y + 30, minWidth: 480, minHeight: 420,
    backgroundColor: '#f7f5f0', title: (title || 'Build') + ' — Unwip', autoHideMenuBar: true,
    icon: path.join(__dirname, 'app', process.platform === 'win32' ? 'icon.ico' : 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, spellcheck: true, offscreen: OFFSCREEN }
  });
  buildWins.set(id, w); taskbarDetails(w);
  w.loadFile(path.join(__dirname, 'app', 'index.html'), { query: { buildwin: id } });
  w.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  w.on('close', e => { if (w.__saved) return; e.preventDefault(); closePopout(w); });
  w.on('closed', () => { if (buildWins.get(id) === w) buildWins.delete(id); });
  return true;
});
ipcMain.handle('popout:list', (_e, slug) => [...popouts.entries()].filter(([k, w]) => !w.isDestroyed() && k.startsWith(slug + '|')).map(([k]) => k.slice(slug.length + 1)));
ipcMain.handle('popout:close', async (_e, slug, id) => { for (const [k, w] of [...popouts.entries()]) if (k.startsWith(slug + '|') && (id == null || k === popKey(slug, id))) await closePopout(w); return true; });
ipcMain.on('popout:saved', (_e, slug, id, words) => tellMain('popout:changed', { slug, id, open: true, words, saved: true }));
ipcMain.on('popout:back', (_e, slug, id) => { const w = popouts.get(popKey(slug, id)); closePopout(w).then(() => { tellMain('popout:back', { slug, id }); if (win && !win.isDestroyed()) win.focus(); }); });

if (process.platform === 'win32') app.setAppUserModelId(DEV ? 'Unwip.Dev' : 'Unwip.Writing');
// One Unwip at a time: opening it again (taskbar, Start menu, a shortcut) brings back the window that's already
// open. Two copies working on the same books could save over each other.
if (!process.env.UNWIP_MULTI && !app.requestSingleInstanceLock()) { app.exit(0); return; }
app.on('second-instance', () => {
  const w = win && !win.isDestroyed() ? win : BrowserWindow.getAllWindows()[0];
  if (w) { if (w.isMinimized()) w.restore(); w.show(); w.focus(); }
});
// the taskbar's name, icon and "open again" for Unwip's windows (otherwise Windows shows the engine's name, "Electron")
function taskbarDetails(w) {
  if (process.platform !== 'win32' || !w || !w.setAppDetails) return;
  try { w.setAppDetails({ appId: DEV ? 'Unwip.Dev' : 'Unwip.Writing', appIconPath: path.join(__dirname, 'app', 'icon.ico'), appIconIndex: 0, relaunchDisplayName: APP_NAME, relaunchCommand: `"${process.execPath}"` + (app.isPackaged ? '' : ` "${app.getAppPath()}"`) }); } catch {}
}
voiceSetup();
app.whenReady().then(() => {
  // allow the editor to list fonts installed on this PC
  // fonts for the font list; screen capture for Proof of writing's screen video (only ever Unwip's own window, see below)
  // ("media" is only allowed for a few seconds after Start screen video is clicked, and never with sound)
  const videoOK = (perm, d) => perm === 'media' && Date.now() < videoArmedUntil && !((d && d.mediaTypes) || []).includes('audio');
  session.defaultSession.setPermissionRequestHandler((_wc, perm, cb, d) => cb(perm === 'local-fonts' || videoOK(perm, d)));
  session.defaultSession.setPermissionCheckHandler((_wc, perm) => perm === 'local-fonts' || videoOK(perm));
  // screen video (Proof of writing): when Unwip asks to record, it records its own window - nothing else on screen
  try { session.defaultSession.setDisplayMediaRequestHandler((request, callback) => { try { callback({ video: request.frame }); } catch { callback({}); } }); } catch {}
  applySpellSettings();
  // no secrets kept: an old GitHub update key (from before updates were public) is removed from the settings file
  try { const st = loadSettings(); if ('updateKey' in st) { delete st.updateKey; saveSettings(st); } } catch {}
  ensureDir(LIBRARY());
  ensureDir(FONT_DIR());
  createWindow();
});
app.on('window-all-closed', () => app.quit());

// ---------- Projects ----------
ipcMain.handle('projects:list', () => {
  ensureDir(LIBRARY());
  const roots = [LIBRARY(), ...extraPlaces().filter(p => fs.existsSync(p))];
  return roots.flatMap(root => fs.readdirSync(root, { withFileTypes: true })
    .filter(d => d.isDirectory() && !['_Deleted', '_Play', '_Build'].includes(d.name) && fs.existsSync(path.join(root, d.name, 'project.json')))
    .map(d => {
      const p = readJSON(path.join(root, d.name, 'project.json'), {});
      // the few documents changed most recently, for "Recently updated" on the main screen
      const recent = []; (function walk(l) { for (const n of l || []) { if (n.type === 'doc' && n.mod && !n.map) recent.push({ id: n.id, title: n.title, mod: n.mod, dev: n.dev || '' }); if (n.children) walk(n.children); } })(p.binder);
      recent.sort((a, b) => b.mod - a.mod);
      return { slug: slugFor(root, d.name), place: placeLabel(root), placeRank: placeRank(root), placePath: path.resolve(root), title: p.title || d.name, words: p.totalWords || 0, modified: p.modified || 0, dev: p.lastDevice || '', recent: recent.slice(0, 3), days: (p.statsVersion === 2 && p.stats && p.stats.days) || {}, goals: p.goals || {}, hours: (p.stats && p.stats.hours) || {}, mins: (p.stats && p.stats.mins) || {}, series: p.series || '', seriesNo: +p.seriesNo || 0, sprints: (p.stats && p.stats.sprints) || [] };
    }))
    .sort((a, b) => b.modified - a.modified);
});
// where a new book can go: the library, plus Dropbox / OneDrive / this PC when they're there
function bookPlaceChoices() {
  const out = [], add = (p, label, note) => { if (p && !out.some(o => same(o.path, p))) out.push({ path: p, label, note: note || '', main: same(p, LIBRARY()) }); };
  add(LIBRARY(), placeLabel(LIBRARY()), 'where your books are now');
  for (const d of dropboxFolders()) { const appDir = path.join(d, 'Apps', FOLDER); if (fs.existsSync(appDir)) add(appDir, 'Dropbox', 'shared with the phone and iPad'); else add(path.join(d, FOLDER), 'Dropbox', 'on your other PCs'); }
  for (const o of oneDriveFolders()) add(path.join(o, FOLDER), 'OneDrive', MAC ? 'on your other computers' : 'on your other PCs');
  if (MAC) { const ic = iCloudDrive(); if (ic) add(path.join(ic, FOLDER), 'iCloud Drive', 'on your other Macs'); }
  add(DEFAULT_LIBRARY(), HERE, 'not synced anywhere');
  for (const p of extraPlaces()) add(p, placeLabel(p));
  return out;
}
ipcMain.handle('projects:places', () => bookPlaceChoices());
ipcMain.handle('projects:pickPlace', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Choose a folder for this book', properties: ['openDirectory', 'createDirectory'] });
  return r.canceled || !r.filePaths.length ? null : r.filePaths[0];
});
function rememberPlace(p) {
  if (same(p, LIBRARY())) return;
  const st = loadSettings(); st.bookPlaces = [...(st.bookPlaces || []).filter(x => !same(x, p)), path.resolve(p)]; saveSettings(st);
}

ipcMain.handle('projects:create', (_e, title, template, place) => {
  const root = place && path.isAbsolute(place) ? path.resolve(place) : LIBRARY();
  ensureDir(root); rememberPlace(root);
  let base = slugify(title), folder = base, n = 2;
  while (fs.existsSync(path.join(root, folder))) folder = `${base} (${n++})`;
  const slug = slugFor(root, folder);
  const dir = ensureDir(projectDir(slug));
  ensureDir(path.join(dir, 'docs'));
  const project = { ...template, title, created: Date.now(), modified: Date.now() };
  writeFileSafe(path.join(dir, 'project.json'), JSON.stringify(project, null, 2));
  return slug;
});

// writing that couldn't be saved yet (disk full and so on): closing the window asks first
let saveTroubleOn = false, closeAnyway = false;
ipcMain.on('save:trouble', (_e, on) => { saveTroubleOn = !!on; });
function guardClose(w) {
  w.on('close', e => {
    if (!saveTroubleOn || closeAnyway) return;
    e.preventDefault();
    const r = dialog.showMessageBoxSync(w, { type: 'warning', buttons: ['Keep Unwip open', 'Close and lose it'], defaultId: 0, cancelId: 0, title: 'Not saved yet',
      message: 'Some of your writing hasn’t been saved yet.', detail: 'Unwip couldn’t save it (the warning at the top of the window says why, often a full disk). If you close now, it will be lost. Fix the problem and Unwip saves it by itself.' });
    if (r === 1) { closeAnyway = true; w.close(); }
  });
}
ipcMain.handle('projects:open', (_e, slug) => {
  const dir = projectDir(slug);
  let raw = null; try { raw = fs.readFileSync(path.join(dir, 'project.json')); } catch {}
  const project = raw ? (() => { try { return JSON.parse(raw.toString('utf8')); } catch { return null; } })() : null;
  if (!project) throw new Error('Could not open project');
  seen(path.join(dir, 'project.json'), raw);
  return project;
});

// A book deleted on another device while it's open here: Dropbox (or OneDrive…) moves its folder into _Deleted, and
// saving into the old place would quietly make the book again, half-empty, and send it back to every device. So a
// save into a book whose project file has gone is written into its copy in Deleted books instead (the latest words
// are kept there), and the window is told the book has gone.
function bookGoneCheck(slug, rel, data) {
  const dir = projectDir(slug);
  if (fs.existsSync(path.join(dir, 'project.json'))) return dir;
  let bin = null;
  try {
    const { root, folder } = placeOf(slug), dd = path.join(root, '_Deleted');
    for (const n of fs.readdirSync(dd)) { const m = /^(\d+) (.+)$/.exec(n); if (m && m[2] === folder && (!bin || +m[1] > bin.ts)) bin = { ts: +m[1], dir: path.join(dd, n) }; }
  } catch {}
  let kept = false;
  if (bin && rel != null) { try { const f = path.join(bin.dir, rel); ensureDir(path.dirname(f)); writeFileSafe(f, data); kept = true; } catch {} }
  throw new Error('BOOK_GONE:' + (bin ? 'bin' : 'none') + (kept ? ':kept' : ''));
}
ipcMain.handle('projects:alive', (_e, slug) => { try { return fs.existsSync(path.join(projectDir(slug), 'project.json')); } catch { return true; } });
ipcMain.handle('projects:saveMeta', (_e, slug, project) => {
  const dir = bookGoneCheck(slug, 'project.json', JSON.stringify({ ...project, modified: Date.now() }, null, 2));
  // a newer Unwip (on another computer, or after a downgrade) stored this project in a way this one doesn't know:
  // never save over it
  const onDisk = readJSON(path.join(dir, 'project.json'), null);
  if (onDisk && (onDisk.format || 1) > (project.format || 1)) throw new Error('NEWER_FORMAT:' + (onDisk.savedBy || 'a newer version'));
  project.modified = Date.now(); project.savedBy = APP_VERSION();
  guardedWrite(slug, path.join(dir, 'project.json'), JSON.stringify(project, null, 2));
  return true;
});

// Deleted books go into a "_Deleted" folder next to them (inside Dropbox too, so other PCs see it in their Deleted
// books), shown in Unwip's own Deleted books list to restore. "Delete forever" sends one to the Windows Recycle Bin.
ipcMain.handle('projects:delete', async (_e, slug) => {
  const dir = projectDir(slug), { root, folder } = placeOf(slug);
  const p = readJSON(path.join(dir, 'project.json'), {});
  const bin = ensureDir(path.join(root, '_Deleted')), dest = path.join(bin, `${Date.now()} ${folder}`);
  try { fs.renameSync(dir, dest); }
  catch { try { fs.cpSync(dir, dest, { recursive: true }); await shell.trashItem(dir); } catch (e) { fs.rmSync(dest, { recursive: true, force: true }); throw e; } }
  try { fs.writeFileSync(path.join(dest, '.deleted.json'), JSON.stringify({ title: p.title || folder, at: Date.now(), by: require('os').hostname() })); } catch {}
  return true;
});
const binId = (root, name) => `${placeKey(root)}|${name}`;
function binPath(id) {
  const [k, name] = String(id).split('|');
  const root = [LIBRARY(), ...extraPlaces()].find(r => placeKey(r) === k);
  if (!root || !name || /[\\/]/.test(name) || name.startsWith('.')) throw new Error('Not found');
  return { root, dir: path.join(root, '_Deleted', name), name };
}
ipcMain.handle('projects:deleted', () => {
  const out = [];
  for (const root of [LIBRARY(), ...extraPlaces()]) {
    const bin = path.join(root, '_Deleted'); if (!fs.existsSync(bin)) continue;
    for (const d of fs.readdirSync(bin, { withFileTypes: true })) {
      if (!d.isDirectory() || !fs.existsSync(path.join(bin, d.name, 'project.json'))) continue;
      const p = readJSON(path.join(bin, d.name, 'project.json'), {}), meta = readJSON(path.join(bin, d.name, '.deleted.json'), {});
      const ts = +(/^(\d{12,})\s/.exec(d.name) || [])[1] || meta.at || fs.statSync(path.join(bin, d.name)).mtimeMs;
      out.push({ id: binId(root, d.name), title: p.title || d.name.replace(/^\d+\s/, ''), words: p.totalWords || 0, at: ts, by: meta.by || '', place: placeLabel(root) });
    }
  }
  return out.sort((a, b) => b.at - a.at);
});
ipcMain.handle('projects:restoreDeleted', (_e, id) => {
  const { root, dir, name } = binPath(id);
  const base = name.replace(/^\d{12,}\s/, '') || 'Restored book'; let folder = base, n = 2;
  while (fs.existsSync(path.join(root, folder))) folder = `${base} (${n++})`;
  fs.renameSync(dir, path.join(root, folder));
  try { fs.rmSync(path.join(root, folder, '.deleted.json'), { force: true }); } catch {}
  return slugFor(root, folder);
});
// Move a book to another place (Dropbox, OneDrive, this PC…): copied there and checked file by file, then the old
// folder goes to the Windows Recycle Bin. Returns the book's new name inside Unwip.
ipcMain.handle('projects:move', async (_e, slug, place) => {
  const from = projectDir(slug), { folder } = placeOf(slug);
  const root = path.resolve(place);
  if (same(path.dirname(from), root)) return slug;
  ensureDir(root); rememberPlace(root);
  let name = folder, n = 2; while (fs.existsSync(path.join(root, name))) name = `${folder} (${n++})`;
  const to = path.join(root, name);
  const list = d => { const out = []; (function walk(x, rel) { for (const e of fs.readdirSync(x, { withFileTypes: true })) { if (/^\.open-on-/.test(e.name)) continue; const r = rel ? rel + '/' + e.name : e.name; if (e.isDirectory()) walk(path.join(x, e.name), r); else out.push([r, fs.statSync(path.join(x, e.name)).size]); } })(d, ''); return out.sort(); };
  fs.cpSync(from, to, { recursive: true, filter: src => !/[\\/]\.open-on-[^\\/]*$/.test(src) });
  const a = JSON.stringify(list(from)), b = JSON.stringify(list(to));
  if (a !== b) { fs.rmSync(to, { recursive: true, force: true }); throw new Error('The copy didn’t match, so nothing was moved.'); }
  try { await shell.trashItem(from); } catch { try { fs.rmSync(from, { recursive: true, force: true }); } catch {} }
  const st = loadSettings(); if (st.lastPlace && st.lastPlace.slug === slug) { st.lastPlace.slug = slugFor(root, name); saveSettings(st); }
  return slugFor(root, name);
});
ipcMain.handle('projects:purgeDeleted', async (_e, id) => { const { dir } = binPath(id); await shell.trashItem(dir); return true; });

ipcMain.handle('projects:reveal', (_e, slug) => shell.openPath(slug ? projectDir(slug) : LIBRARY()));

// ---------- Documents ----------
// ---------- Play (practice writing, kept apart from projects in Documents\Unwip\_Play) ----------
const PLAY_DIR = () => path.join(LIBRARY(), '_Play');
ipcMain.handle('play:load', () => readJSON(path.join(PLAY_DIR(), 'play.json'), { pieces: [], days: {} }));
ipcMain.handle('play:save', (_e, index) => { ensureDir(PLAY_DIR()); writeFileSafe(path.join(PLAY_DIR(), 'play.json'), JSON.stringify(index, null, 2)); return true; });
ipcMain.handle('play:loadPiece', (_e, id) => { try { return fs.readFileSync(path.join(PLAY_DIR(), 'pieces', safeId(id) + '.html'), 'utf8'); } catch { return ''; } });
ipcMain.handle('play:savePiece', (_e, id, html) => { const d = ensureDir(path.join(PLAY_DIR(), 'pieces')); writeFileSafe(path.join(d, safeId(id) + '.html'), html); return true; });
ipcMain.handle('play:deletePiece', (_e, id) => { try { fs.unlinkSync(path.join(PLAY_DIR(), 'pieces', safeId(id) + '.html')); } catch {} return true; });

// ---- Build: maps, magic systems, runes, sigils and coats of arms that belong to the whole world, not one book.
// Kept in the Dropbox app folder when there is one (so the phone and iPad see them), otherwise in the library.
const BUILD_DIR = () => { for (const d of dropboxFolders()) { const a = path.join(d, 'Apps', FOLDER); if (fs.existsSync(a)) return path.join(a, '_Build'); } return path.join(LIBRARY(), '_Build'); };
function buildItems() {
  const dir = path.join(BUILD_DIR(), 'items');
  // made before Dropbox was set up: bring them along
  const old = path.join(LIBRARY(), '_Build', 'items');
  if (!same(old, dir) && fs.existsSync(old)) { ensureDir(dir); for (const f of fs.readdirSync(old)) if (!fs.existsSync(path.join(dir, f))) try { fs.copyFileSync(path.join(old, f), path.join(dir, f)); } catch {} }
  return dir;
}
// ---- settings shared between devices (themes, typewriter, LitRPG shortcuts…): one small file next to Build, so the
// Dropbox app carries it to the phone. Dropbox's own "conflicted copy" files of it are handed over too, to be merged
// (newest change of each setting wins) and then removed.
const PREFS_DIR = () => path.join(path.dirname(BUILD_DIR()), '_Settings');
ipcMain.handle('prefs:read', () => {
  const dir = PREFS_DIR(); let main = null; const extra = [];
  try { main = fs.readFileSync(path.join(dir, 'shared.json'), 'utf8'); } catch {}
  try { for (const f of fs.readdirSync(dir)) if (/^shared .*conflicted copy.*\.json$/i.test(f)) try { extra.push({ name: f, text: fs.readFileSync(path.join(dir, f), 'utf8') }); } catch {} } catch {}
  return { main, extra };
});
ipcMain.handle('prefs:write', (_e, json, merged) => {
  const dir = ensureDir(PREFS_DIR()); writeFileSafe(path.join(dir, 'shared.json'), json);
  for (const f of merged || []) if (/^shared .*conflicted copy.*\.json$/i.test(f) && !f.includes('/') && !f.includes('\\')) try { fs.unlinkSync(path.join(dir, f)); } catch {}
  return true;
});
ipcMain.handle('build:list', () => {
  const dir = buildItems(); if (!fs.existsSync(dir)) return [];
  // Dropbox's own app keeps both versions when a piece changed in two places ("… (PC's conflicted copy …).json"):
  // turn that copy into a piece of its own, so it shows in Build instead of hiding in the folder
  for (const f of fs.readdirSync(dir)) {
    if (/^[\w-]+\.json$/.test(f) || !/conflicted copy/i.test(f) || !/\.json$/i.test(f)) continue;
    try { const x = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8')); const id = 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); x.id = id; x.title = (x.title || 'Untitled') + ' (other version)'; writeFileSafe(path.join(dir, id + '.json'), JSON.stringify(x)); fs.rmSync(path.join(dir, f), { force: true }); } catch {}
  }
  return fs.readdirSync(dir).filter(f => /^[\w-]+\.json$/.test(f)).map(f => { const x = readJSON(path.join(dir, f), null); return x && x.id ? { id: x.id, kind: x.kind, title: x.title, created: x.created, updated: x.updated, thumb: x.thumb || '', world: x.world || '' } : null; }).filter(Boolean);
});
ipcMain.handle('build:load', (_e, id) => readJSON(path.join(buildItems(), safeId(id) + '.json'), null));
ipcMain.handle('build:save', (_e, id, json) => { const d = ensureDir(buildItems()); writeFileSafe(path.join(d, safeId(id) + '.json'), json); return true; });
ipcMain.handle('build:delete', (_e, id) => { try { fs.unlinkSync(path.join(buildItems(), safeId(id) + '.json')); } catch {} return true; });

ipcMain.handle('docs:load', (_e, slug, id) => {
  const p = path.join(projectDir(slug), 'docs', safeId(id) + '.html');
  try { const d = fs.readFileSync(p); seen(p, d); return d.toString('utf8'); } catch { return ''; }
});
ipcMain.handle('docs:save', async (e, slug, id, html) => {
  bookGoneCheck(slug, `docs/${safeId(id)}.html`, html);
  const dir = ensureDir(path.join(projectDir(slug), 'docs'));
  // the main window changing a chapter that's open in its own window (Replace all, say): that window saves what's
  // typed there first, then shows the change
  const pw = popouts.get(popKey(slug, id)), fromMain = pw && !pw.isDestroyed() && e.sender !== pw.webContents;
  if (fromMain) { try { await Promise.race([pw.webContents.executeJavaScript('window.__flush ? window.__flush() : 1'), new Promise(r => setTimeout(r, 3000))]); } catch {} }
  guardedWrite(slug, path.join(dir, safeId(id) + '.html'), html);
  if (fromMain && !pw.isDestroyed()) pw.webContents.send('project:external', { slug, file: `docs/${safeId(id)}.html`, id });
  return true;
});

// ---------- Snapshots (saved versions of a single document) ----------
const snapDir = (slug, id) => path.join(projectDir(slug), 'snapshots', safeId(id));
ipcMain.handle('snap:save', (_e, slug, id, html, label, auto) => {
  bookGoneCheck(slug, null);
  const dir = ensureDir(snapDir(slug, id));
  const ts = Date.now();
  writeFileSafe(path.join(dir, ts + '.html'), html);
  const metaFile = path.join(dir, 'snapshots.json');
  const meta = readJSON(metaFile, []);
  meta.push({ ts, label: label || '', auto: !!auto });
  // keep at most 40 automatic snapshots per document (named ones are never removed)
  const autos = meta.filter(m => m.auto);
  while (autos.length > 40) { const old = autos.shift(); meta.splice(meta.indexOf(old), 1); fs.rmSync(path.join(dir, old.ts + '.html'), { force: true }); }
  writeFileSafe(metaFile, JSON.stringify(meta, null, 2));
  return ts;
});
ipcMain.handle('snap:list', (_e, slug, id) => readJSON(path.join(snapDir(slug, id), 'snapshots.json'), []).sort((a, b) => b.ts - a.ts));
ipcMain.handle('snap:load', (_e, slug, id, ts) => { try { return fs.readFileSync(path.join(snapDir(slug, id), Number(ts) + '.html'), 'utf8'); } catch { return null; } });
ipcMain.handle('snap:delete', (_e, slug, id, ts) => {
  const dir = snapDir(slug, id), metaFile = path.join(dir, 'snapshots.json');
  const meta = readJSON(metaFile, []).filter(m => m.ts !== Number(ts));
  writeFileSafe(metaFile, JSON.stringify(meta, null, 2));
  fs.rmSync(path.join(dir, Number(ts) + '.html'), { force: true });
  return true;
});
ipcMain.handle('snap:rename', (_e, slug, id, ts, label) => {
  const metaFile = path.join(snapDir(slug, id), 'snapshots.json');
  const meta = readJSON(metaFile, []); const m = meta.find(x => x.ts === Number(ts)); if (m) { m.label = label; m.auto = false; }
  writeFileSafe(metaFile, JSON.stringify(meta, null, 2)); return true;
});

// ---------- Media (moodboard images), stored inside the project ----------
const mediaDir = slug => ensureDir(path.join(projectDir(slug), 'media'));
const IMG_EXT = ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'avif'];
function storeMedia(slug, bytes, ext) {
  ext = String(ext || 'png').toLowerCase().replace(/[^a-z0-9]/g, '');
  if (!IMG_EXT.includes(ext)) ext = 'png';
  bookGoneCheck(slug, null);
  const id = 'm' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  fs.writeFileSync(path.join(mediaDir(slug), id + '.' + ext), Buffer.from(bytes));
  return id + '.' + ext;
}
ipcMain.handle('media:pick', async (_e, slug) => {
  const res = await dialog.showOpenDialog(win, { title: 'Add images', properties: ['openFile', 'multiSelections'], filters: [{ name: 'Images', extensions: IMG_EXT }] });
  if (res.canceled) return [];
  return res.filePaths.map(f => ({ file: storeMedia(slug, fs.readFileSync(f), path.extname(f).slice(1)), name: path.basename(f) }));
});
ipcMain.handle('media:add', (_e, slug, bytes, ext) => storeMedia(slug, bytes, ext));
// pictures placed inside a chapter: the screen shrinks and embeds them, so just hand over the file
ipcMain.handle('image:pick', async () => {
  const res = await dialog.showOpenDialog(win, { title: 'Insert a picture', properties: ['openFile'], filters: [{ name: 'Images', extensions: IMG_EXT }] });
  if (res.canceled || !res.filePaths.length) return null;
  const f = res.filePaths[0]; const ext = path.extname(f).slice(1).toLowerCase();
  return { name: path.basename(f), type: 'image/' + (ext === 'jpg' ? 'jpeg' : ext), bytes: fs.readFileSync(f) };
});
ipcMain.handle('media:get', (_e, slug, file) => {
  const f = path.join(mediaDir(slug), path.basename(String(file)));
  try {
    const ext = path.extname(f).slice(1).toLowerCase();
    const mime = ext === 'jpg' ? 'jpeg' : ext;
    return `data:image/${mime};base64,` + fs.readFileSync(f).toString('base64');
  } catch { return null; }
});

// ---------- Import ----------
// pictures in a Scrivener project come back as data: addresses (the screen shrinks big ones)
function picFile(f) { try { const ext = path.extname(f).slice(1).toLowerCase(); return `data:image/${ext === 'jpg' ? 'jpeg' : ext};base64,` + fs.readFileSync(f).toString('base64'); } catch { return null; } }
// Scrivener: returns the binder file and every document's text, synopsis and notes
ipcMain.handle('import:scrivener', async () => {
  const res = await dialog.showOpenDialog(win, {
    title: 'Choose a Scrivener project (.scriv folder, or the .scrivx file inside it)',
    properties: ['openDirectory', 'openFile'],
    filters: [{ name: 'Scrivener project', extensions: ['scrivx', 'scriv'] }]
  });
  if (res.canceled || !res.filePaths.length) return null;
  let p = res.filePaths[0];
  let scrivDir = p, scrivx = null;
  if (p.toLowerCase().endsWith('.scrivx')) { scrivx = p; scrivDir = path.dirname(p); }
  else {
    const found = fs.readdirSync(p).find(f => f.toLowerCase().endsWith('.scrivx'));
    if (!found) throw new Error('That folder is not a Scrivener project (no .scrivx file inside).');
    scrivx = path.join(p, found);
  }
  const files = {};
  const read = (f) => { try { return fs.readFileSync(f, 'utf8'); } catch { return null; } };
  // A project made in Scrivener on iPhone or iPad and not yet opened on a computer keeps everything in a "Mobile"
  // folder: the .scrivx is only a placeholder (MobileStub="Yes"), the binder is Mobile/binder.mob and the
  // documents are in Mobile/Data, laid out like Scrivener 3's Files/Data.
  let binderXML = read(scrivx), dataDir = path.join(scrivDir, 'Files', 'Data'), mobilePending = false;
  const mob = path.join(scrivDir, 'Mobile', 'binder.mob');
  const isStub = !binderXML || /MobileStub\s*=\s*"Yes"/i.test(binderXML) || !/<Binder[\s>]/.test(binderXML);
  const hasSpare = ['binder.autosave', 'binder.backup'].some(f => /<Binder[\s>]/.test(read(path.join(scrivDir, 'Files', f)) || ''));
  if (isStub && !fs.existsSync(mob) && hasSpare) { /* a damaged .scrivx with Scrivener's spare binder copies: the renderer uses those */ }
  else if (isStub) {
    if (!fs.existsSync(mob)) throw new Error('This project was made in Scrivener on an iPhone or iPad, and its writing isn’t in the folder yet (Dropbox may still be downloading it). Open it once in Scrivener, then try again.');
    binderXML = read(mob); dataDir = path.join(scrivDir, 'Mobile', 'Data');
  } else if (fs.existsSync(mob)) mobilePending = true;   // edits from a phone or iPad that Scrivener on a computer hasn't taken in yet
  if (fs.existsSync(dataDir)) {                                     // Scrivener 3 (and mobile)
    for (const uuid of fs.readdirSync(dataDir)) {
      const d = path.join(dataDir, uuid);
      if (!fs.statSync(d).isDirectory()) continue;
      files[uuid] = { content: read(path.join(d, 'content.rtf')), synopsis: read(path.join(d, 'synopsis.txt')), notes: read(path.join(d, 'notes.rtf')) };
      const pic = fs.readdirSync(d).find(f => /^content\.(png|jpe?g|gif|webp)$/i.test(f));
      if (pic) files[uuid].image = picFile(path.join(d, pic));
    }
  }
  const docsDir = path.join(scrivDir, 'Files', 'Docs');            // Scrivener 1 & 2
  if (fs.existsSync(docsDir)) {
    for (const f of fs.readdirSync(docsDir)) {
      const pm = f.match(/^(\d+)\.(png|jpe?g|gif|webp)$/i);
      if (pm) { (files[pm[1]] = files[pm[1]] || {}).image = picFile(path.join(docsDir, f)); continue; }
      const m = f.match(/^(\d+)(_synopsis\.txt|_notes\.rtf|\.rtf)$/i); if (!m) continue;
      const e = files[m[1]] = files[m[1]] || {};
      const key = /synopsis/i.test(m[2]) ? 'synopsis' : /notes/i.test(m[2]) ? 'notes' : 'content';
      e[key] = read(path.join(docsDir, f));
    }
  }
  // Scrivener's own spare copies of the binder, in case the main project file is damaged
  const spares = []; for (const f of ['binder.autosave', 'binder.backup']) { const t = read(path.join(scrivDir, 'Files', f)); if (t && /<Binder[\s>]/.test(t)) { let at = 0; try { at = fs.statSync(path.join(scrivDir, 'Files', f)).mtimeMs; } catch {} spares.push({ name: f, xml: t, at }); } }
  return { name: path.basename(scrivDir).replace(/\.scriv$/i, ''), scrivx: binderXML, files, mobile: isStub, mobilePending, spares };
});
ipcMain.handle('import:docx', async () => {
  const res = await dialog.showOpenDialog(win, { title: 'Import a Word document', properties: ['openFile'], filters: [{ name: 'Word document', extensions: ['docx'] }] });
  if (res.canceled || !res.filePaths.length) return null;
  const f = res.filePaths[0];
  return { name: path.basename(f).replace(/\.docx$/i, ''), bytes: fs.readFileSync(f) };
});

// Books from other programs: Word, LibreOffice, RTF, plain text, Markdown, web pages - one file, several, or a whole folder
const BOOK_EXT = ['docx', 'odt', 'rtf', 'txt', 'md', 'markdown', 'text', 'htm', 'html'];
const bookFile = f => ({ name: path.basename(f).replace(/\.[^.]+$/, ''), ext: path.extname(f).slice(1).toLowerCase(), bytes: fs.readFileSync(f) });
ipcMain.handle('import:files', async () => {
  const res = await dialog.showOpenDialog(win, { title: 'Choose your book (pick several files to bring in several chapters)', properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'Writing (Word, Google Docs download, LibreOffice, RTF, text, Markdown)', extensions: BOOK_EXT }, { name: 'All files', extensions: ['*'] }] });
  if (res.canceled || !res.filePaths.length) return null;
  return res.filePaths.map(bookFile);
});
ipcMain.handle('import:folder', async () => {
  const res = await dialog.showOpenDialog(win, { title: 'Choose the folder that holds your chapter files', properties: ['openDirectory'] });
  if (res.canceled || !res.filePaths.length) return null;
  const dir = res.filePaths[0];
  // an Unwip book folder (project.json + docs), or a folder of them (a copy of Dropbox/Apps/Unwip): these are books
  // already, so they come in as books. Read as chapter files, docs/*.html and snapshots/ turned into "chapters" with
  // id names and Characters stayed empty.
  const isBook = d => { try { return fs.existsSync(path.join(d, 'project.json')) && fs.statSync(path.join(d, 'docs')).isDirectory(); } catch { return false; } };
  let bookDirs = isBook(dir) ? [dir] : [];
  if (!bookDirs.length) { try { bookDirs = fs.readdirSync(dir, { withFileTypes: true }).filter(e => e.isDirectory() && !/^[_.]/.test(e.name) && isBook(path.join(dir, e.name))).map(e => path.join(dir, e.name)); } catch {} }
  if (bookDirs.length) {
    const build = [path.join(dir, '_Build', 'items'), path.join(path.dirname(dir), '_Build', 'items')].find(d => { try { return fs.readdirSync(d).some(f => f.endsWith('.json')); } catch { return false; } });
    return { folder: path.basename(dir), files: [], books: bookDirs.map(d => ({ path: d, title: (readJSON(path.join(d, 'project.json'), {}).title) || path.basename(d) })), build: build || null };
  }
  // sub-folders too (an Obsidian vault, say): each file remembers its sub-folder so the binder can rebuild them.
  // Hidden folders (.obsidian, .trash, .git) and drawings (.excalidraw.md) are skipped.
  const found = [];
  (function walk(d, rel, depth) {
    let ents = []; try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const e of ents) {
      if (/^[~.]/.test(e.name) || found.length >= 3000) continue;
      const full = path.join(d, e.name);
      if (e.isDirectory()) { if (depth < 8 && !/^(node_modules)$/i.test(e.name)) walk(full, rel ? rel + '/' + e.name : e.name, depth + 1); continue; }
      if (!BOOK_EXT.includes(path.extname(e.name).slice(1).toLowerCase()) || /\.excalidraw\.md$/i.test(e.name)) continue;
      try { if (fs.statSync(full).isFile()) found.push({ ...bookFile(full), dir: rel }); } catch {}
    }
  })(dir, '', 0);
  return { folder: path.basename(dir), files: found };
});

// an Unwip book folder chosen in Import › a folder: each book comes in as a new book (a copy; its backups and
// open-on markers stay behind), and Build pieces next to it join Build unless one with that id is already there
ipcMain.handle('import:unwipBooks', (_e, dirs, buildDir) => {
  const out = [];
  const have = new Set(listTitles());
  for (const d of Array.isArray(dirs) ? dirs : []) {
    if (!fs.existsSync(path.join(d, 'project.json'))) continue;
    const files = [];
    (function walk(dd, rel) {
      for (const e of fs.readdirSync(dd, { withFileTypes: true })) {
        if (/^\./.test(e.name) || (!rel && e.name === 'backups')) continue;
        const full = path.join(dd, e.name), r = rel ? rel + '/' + e.name : e.name;
        if (e.isDirectory()) walk(full, r); else if (e.isFile()) files.push({ name: r, data: fs.readFileSync(full) });
      }
    })(d, '');
    const title = readJSON(path.join(d, 'project.json'), {}).title || '';
    out.push(restoreArchive(zipFiles(files), have.has(title) ? ' (imported)' : ''));
  }
  let pieces = 0;
  if (buildDir && fs.existsSync(buildDir)) {
    const to = ensureDir(buildItems());
    for (const f of fs.readdirSync(buildDir)) if (/^[\w-]+\.json$/.test(f) && !fs.existsSync(path.join(to, f))) { try { fs.copyFileSync(path.join(buildDir, f), path.join(to, f)); pieces++; } catch {} }
  }
  return { slugs: out, pieces };
});
function listTitles() { const root = LIBRARY(); try { return fs.readdirSync(root, { withFileTypes: true }).filter(x => x.isDirectory() && fs.existsSync(path.join(root, x.name, 'project.json'))).map(x => readJSON(path.join(root, x.name, 'project.json'), {}).title || ''); } catch { return []; } }

// ---------- Backups ----------
ipcMain.handle('backup:make', (_e, slug) => makeBackup(slug));
function makeBackup(slug) {
  const dir = projectDir(slug);
  if (!fs.existsSync(path.join(dir, 'project.json'))) return null;   // the book has gone (deleted on another device): don't make it again
  const bdir = ensureDir(path.join(dir, 'backups'));
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const target = path.join(bdir, stamp);
  ensureDir(path.join(target, 'docs'));
  fs.copyFileSync(path.join(dir, 'project.json'), path.join(target, 'project.json'));
  for (const f of fs.readdirSync(path.join(dir, 'docs'))) {
    if (f.endsWith('.html')) fs.copyFileSync(path.join(dir, 'docs', f), path.join(target, 'docs', f));
  }
  // images (moodboard etc.) never change once added, so they're kept once in backups/media rather than in every backup
  const mdir = path.join(dir, 'media');
  if (fs.existsSync(mdir)) {
    const bm = ensureDir(path.join(bdir, 'media'));
    for (const f of fs.readdirSync(mdir)) if (!fs.existsSync(path.join(bm, f))) fs.copyFileSync(path.join(mdir, f), path.join(bm, f));
  }
  extraBackup(slug, false);
  const all = fs.readdirSync(bdir).filter(f => /^\d{4}-/.test(f)).sort();
  for (const f of backupsToPrune(all)) fs.rmSync(path.join(bdir, f), { recursive: true, force: true });
  return stamp;
}

// ---------- Clipboard ----------
ipcMain.handle('clipboard:write', (_e, html, text) => { clipboard.write({ html, text }); return true; });
// pictures (Build's and the map's Copy picture): the window's own clipboard isn't allowed to write images here
ipcMain.handle('clipboard:image', (_e, bytes) => { const img = nativeImage.createFromBuffer(Buffer.from(bytes)); if (img.isEmpty()) return false; clipboard.writeImage(img); const s = clipboard.readImage().getSize(); return s.width > 0 ? s : false; });
ipcMain.handle('clipboard:read', () => ({ html: clipboard.readHTML(), rtf: clipboard.readRTF(), text: clipboard.readText() }));
ipcMain.handle('clipboard:paste', () => { win.webContents.paste(); return true; });
// the level the window is at (Focus 0, Detail 1, Lore 2): the right-click menu shows Lore's extras only at Lore
let uiLevel = 0;
ipcMain.on('ui:level', (_e, l) => { uiLevel = Number(l) || 0; });

// Saves a report of exactly what another program put on the clipboard, so paste problems can be diagnosed
function clipboardCheck() {
  const formats = clipboard.availableFormats();
  const html = clipboard.readHTML();
  const rtf = clipboard.readRTF();
  const text = clipboard.readText();
  const cut = (s, n) => (s || '').length > n ? s.slice(0, n) + `\n... [${s.length - n} more characters]` : (s || '(empty)');
  const report = [
    'UNWIP CLIPBOARD CHECK',
    `Made: ${new Date().toString()}`,
    '',
    'Formats on the clipboard:',
    ...formats.map(f => '  - ' + f),
    '',
    '===== HTML =====', cut(html, 30000), '',
    '===== RTF =====', cut(rtf, 30000), '',
    '===== PLAIN TEXT (first 2000 characters) =====', cut(text, 2000)
  ].join('\r\n');
  const file = path.join(LIBRARY(), 'clipboard-check.txt');
  fs.writeFileSync(file, report);
  shell.showItemInFolder(file);
}

// ---------- Fonts ----------
ipcMain.handle('fonts:import', async () => {
  const res = await dialog.showOpenDialog(win, {
    title: 'Import font files',
    properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'Fonts', extensions: ['ttf', 'otf', 'woff', 'woff2'] }]
  });
  if (res.canceled) return [];
  for (const f of res.filePaths) fs.copyFileSync(f, path.join(FONT_DIR(), path.basename(f)));
  return listImportedFonts();
});
function listImportedFonts() {
  ensureDir(FONT_DIR());
  return fs.readdirSync(FONT_DIR())
    .filter(f => /\.(ttf|otf|woff2?)$/i.test(f))
    .map(f => ({ file: f, data: fs.readFileSync(path.join(FONT_DIR(), f)).toString('base64') }));
}
ipcMain.handle('fonts:imported', () => listImportedFonts());

// ---------- Export ----------
// Render HTML to PDF in a hidden window. opts: { pageSize, margins (inches), pageNumbers }
async function renderPDF(html, opts = {}) {
  const tmp = path.join(app.getPath('temp'), 'folio-export-' + Date.now() + '.html');
  fs.writeFileSync(tmp, html);
  // raw: a fully laid-out book (typeset.js) whose pages are already the trim size; scripts on only to wait for fonts
  const pw = new BrowserWindow({ show: false, webPreferences: { javascript: !!opts.raw, offscreen: OFFSCREEN } });
  try {
    await pw.loadFile(tmp);
    if (opts.raw) {
      await pw.webContents.executeJavaScript('document.fonts.ready.then(() => new Promise(r => setTimeout(r, 150))).then(() => 1)');
      return await pw.webContents.printToPDF({ pageSize: opts.pageSize, printBackground: true, preferCSSPageSize: true, margins: { marginType: 'none' }, displayHeaderFooter: false });
    }
    const m = opts.margins || { top: 0.9, bottom: 0.9, left: 0.9, right: 0.9 };
    const pdf = await pw.webContents.printToPDF({
      pageSize: opts.pageSize || 'A4',
      printBackground: true,
      margins: { marginType: 'custom', ...m },
      displayHeaderFooter: !!(opts.pageNumbers || opts.header),
      headerTemplate: opts.header ? `<div style="width:100%;text-align:right;padding-right:0.9in;font-family:'Times New Roman',serif;font-size:10px;color:#000">${String(opts.header).replace(/[<>&]/g, '')}<span class="pageNumber"></span></div>` : '<span></span>',
      footerTemplate: opts.pageNumbers ? `<div style="width:100%;text-align:center;font-family:${(opts.font || 'Times New Roman').replace(/[<>"]/g, '')},serif;font-size:9px;color:#333"><span class="pageNumber"></span></div>` : '<span></span>'
    });
    return pdf;
  } finally {
    pw.destroy();
    fs.rm(tmp, { force: true }, () => {});
  }
}
function countPdfPages(buf) {
  const m = buf.toString('latin1').match(/\/Type\s*\/Page[^s]/g);
  return m ? m.length : 0;
}
ipcMain.handle('export:pdf', async (_e, html, suggestedName, pageSize, opts = {}) => {
  const res = await dialog.showSaveDialog(win, {
    title: 'Export PDF',
    defaultPath: path.join(app.getPath('documents'), slugify(suggestedName) + '.pdf'),
    filters: [{ name: 'PDF', extensions: ['pdf'] }]
  });
  if (res.canceled) return null;
  const pdf = await renderPDF(html, { ...opts, pageSize });
  fs.writeFileSync(res.filePath, pdf);
  shell.showItemInFolder(res.filePath);
  return { path: res.filePath, pages: countPdfPages(pdf) };
});
// exact page count without saving anything
ipcMain.handle('export:pdfPages', async (_e, html, pageSize, opts = {}) => countPdfPages(await renderPDF(html, { ...opts, pageSize })));

// save any generated file (e.g. EPUB) after asking where
// "No hard feelings": a Scrivener project (.scriv folder) wherever you choose
ipcMain.handle('export:scriv', async (_e, name, files) => {
  const res = await dialog.showOpenDialog(win, { title: 'Choose where to put the Scrivener project', defaultPath: app.getPath('documents'), properties: ['openDirectory', 'createDirectory'] });
  if (res.canceled || !res.filePaths.length) return null;
  const clean = s => winName(String(s).replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim() || 'Untitled');
  let base = path.join(res.filePaths[0], clean(name) + '.scriv'), n = 2;
  // one there already (from an earlier export): replace it, rather than piling up numbered copies
  if (fs.existsSync(base)) {
    const r = await dialog.showMessageBox(win, { type: 'question', buttons: ['Replace it', 'Keep both', 'Cancel'], defaultId: 0, cancelId: 2, title: 'Already there',
      message: `“${path.basename(base)}” is already in that folder.`, detail: 'Replace it with this new one? The old one goes to the Recycle Bin, so you can still get it back. Or keep both, and the new one gets a number.' });
    if (r.response === 2) return null;
    if (r.response === 0) { try { await shell.trashItem(base); } catch { const old = base.replace(/\.scriv$/, ` (old ${Date.now()}).scriv`); fs.renameSync(base, old); } }
  }
  while (fs.existsSync(base)) base = path.join(res.filePaths[0], `${clean(name)} (${n++}).scriv`);
  for (const f of files) {
    const dest = path.join(base, ...String(f.name).split('/').filter(Boolean).map(clean));
    if (!dest.startsWith(base + path.sep)) continue;
    if (f.dir) { fs.mkdirSync(LP(dest), { recursive: true }); continue; }
    fs.mkdirSync(LP(path.dirname(dest)), { recursive: true });
    fs.writeFileSync(LP(dest), Buffer.from(f.data));
  }
  shell.showItemInFolder(base);
  return path.basename(base);
});
// a folder of files (one per chapter), in a new folder wherever you choose
ipcMain.handle('export:folder', async (_e, name, files) => {
  const res = await dialog.showOpenDialog(win, { title: 'Choose where to put the folder', defaultPath: app.getPath('documents'), properties: ['openDirectory', 'createDirectory'] });
  if (res.canceled || !res.filePaths.length) return null;
  const clean = s => winName(String(s).replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim() || 'Untitled');
  let base = path.join(res.filePaths[0], clean(name) + ' (from Unwip)'), n = 2;
  while (fs.existsSync(base)) base = path.join(res.filePaths[0], `${clean(name)} (from Unwip ${n++})`);
  for (const f of files) {
    const parts = String(f.name).split('/').map(clean), dest = path.join(base, ...parts);
    if (!dest.startsWith(base + path.sep)) continue;
    fs.mkdirSync(LP(path.dirname(dest)), { recursive: true });
    fs.writeFileSync(LP(dest), Buffer.from(f.data));
  }
  shell.openPath(base);
  return path.basename(base);
});
ipcMain.handle('export:binary', async (_e, bytes, suggestedName, ext, label) => {
  const res = await dialog.showSaveDialog(win, {
    title: 'Export ' + label,
    defaultPath: path.join(app.getPath('documents'), slugify(suggestedName) + '.' + ext),
    filters: [{ name: label, extensions: [ext] }]
  });
  if (res.canceled) return null;
  fs.writeFileSync(res.filePath, Buffer.from(bytes));
  shell.showItemInFolder(res.filePath);
  return res.filePath;
});

ipcMain.handle('export:html', async (_e, html, suggestedName) => {
  const res = await dialog.showSaveDialog(win, {
    title: 'Export for Word / Google Docs',
    defaultPath: path.join(app.getPath('documents'), slugify(suggestedName) + '.html'),
    filters: [{ name: 'Web page (opens in Word and Google Docs)', extensions: ['html'] }]
  });
  if (res.canceled) return null;
  fs.writeFileSync(res.filePath, html);
  shell.showItemInFolder(res.filePath);
  return res.filePath;
});

// ---------- Proof of writing ----------
// Replays: a record of every change made while recording, one file per writing session, kept in the book's own
// folder (proof/<session>.json) so they travel with the book and sync like it.
const proofDir = slug => path.join(projectDir(slug), 'proof');
const proofName = n => { const v = String(n || '').replace(/[^\w-]/g, ''); if (!v) throw new Error('Bad name'); return v + '.json'; };
ipcMain.handle('proof:list', (_e, slug) => {
  try { return fs.readdirSync(proofDir(slug)).filter(f => /^[\w-]+\.json$/.test(f)).map(f => { const st = fs.statSync(path.join(proofDir(slug), f)); return { name: f.slice(0, -5), size: st.size, at: st.mtimeMs }; }); } catch { return []; }
});
ipcMain.handle('proof:read', (_e, slug, name) => { try { return fs.readFileSync(path.join(proofDir(slug), proofName(name)), 'utf8'); } catch { return null; } });
ipcMain.handle('proof:write', (_e, slug, name, text) => { bookGoneCheck(slug, null); ensureDir(proofDir(slug)); writeFileSafe(path.join(proofDir(slug), proofName(name)), String(text)); return true; });
ipcMain.handle('proof:delete', (_e, slug, name) => { try { fs.rmSync(path.join(proofDir(slug), proofName(name)), { force: true }); } catch {} return true; });

// Screen video: the page records Unwip's own window and sends the video here a few seconds at a time, so even a
// long recording is written straight to disk and never held in memory.
let video = null;   // { fd, path, bytes }
let videoArmedUntil = 0;
ipcMain.handle('video:arm', () => { videoArmedUntil = Date.now() + 10000; return true; });
const videoFolder = () => { const d = path.join(app.getPath('videos'), FOLDER); ensureDir(d); return d; };
function freeBytes(dir) { try { const st = fs.statfsSync(dir); return st.bavail * st.bsize; } catch { return null; } }
ipcMain.handle('video:info', () => { const dir = videoFolder(); return { folder: dir, free: freeBytes(dir) }; });
ipcMain.handle('video:begin', async (_e, suggested, ext) => {
  if (video) { try { fs.closeSync(video.fd); } catch {} video = null; }
  const dir = videoFolder(), base = slugify(suggested || 'Unwip recording');
  let file = path.join(dir, `${base}.${ext}`), n = 2;
  while (fs.existsSync(file)) file = path.join(dir, `${base} (${n++}).${ext}`);
  video = { fd: fs.openSync(file, 'w'), path: file, bytes: 0 };
  try { fs.writeFileSync(file + '.recording', String(Date.now())); } catch {}   // removed when it's finished properly
  return { path: file, free: freeBytes(dir) };
});
ipcMain.handle('video:chunk', (_e, bytes) => {
  if (!video) return { ok: false };
  const b = Buffer.from(bytes); fs.writeSync(video.fd, b); video.bytes += b.length;
  return { ok: true, bytes: video.bytes, free: freeBytes(path.dirname(video.path)) };
});
ipcMain.handle('video:end', async () => {
  if (!video) return null;
  const v = video; video = null;
  try { fs.closeSync(v.fd); } catch {}
  try { fs.rmSync(v.path + '.recording', { force: true }); } catch {}
  if (!v.bytes) { try { fs.rmSync(v.path, { force: true }); } catch {} return null; }
  // add the video's length and an index, so players can skip through it (the original stays if this fails)
  let seekable = false;
  if (/\.webm$/i.test(v.path)) { try { await require(path.join(__dirname, 'app', 'webmfix.js')).fixFile(v.path); seekable = true; } catch (e) { console.error('webm fix', e); } }
  return { path: v.path, bytes: fs.statSync(v.path).size, seekable };
});
ipcMain.handle('video:reveal', (_e, file) => { if (file && fs.existsSync(file)) shell.showItemInFolder(file); });
// Quitting while a screen video records: the file is closed and, for WebM, given its length and index so players can
// open it (that step used to be skipped, leaving a file Windows' Media Player refused). The marker beside the file goes
// once it's done. A recording cut off harder than that (a crash, power) is repaired the next time Unwip starts.
let videoQuitting = false;
app.on('before-quit', e => {
  if (!video || videoQuitting) return;
  e.preventDefault(); videoQuitting = true;
  const v = video; video = null;
  try { fs.closeSync(v.fd); } catch {}
  repairVideo(v.path).finally(() => app.quit());
});
async function repairVideo(file) {
  try {
    if (fs.existsSync(file) && fs.statSync(file).size === 0) fs.rmSync(file, { force: true });
    else if (/\.webm$/i.test(file) && fs.existsSync(file)) await require(path.join(__dirname, 'app', 'webmfix.js')).fixFile(file);
  } catch (e) { console.error('video repair', e); }
  try { fs.rmSync(file + '.recording', { force: true }); } catch {}
}
// on start: any recording that never finished gets the same repair
app.whenReady().then(() => setTimeout(async () => {
  try {
    const dir = path.join(app.getPath('videos'), FOLDER); if (!fs.existsSync(dir)) return;
    for (const f of fs.readdirSync(dir)) if (f.endsWith('.recording')) await repairVideo(path.join(dir, f.slice(0, -'.recording'.length)));
  } catch (e) { console.error('video repair on start', e); }
}, 4000));

// ---------- App settings (spelling language etc.), kept in a small file ----------
const SETTINGS_FILE = () => path.join(app.getPath('userData'), 'settings.json');
function loadSettings() { return readJSON(SETTINGS_FILE(), {}); }
function saveSettings(s) { writeFileSafe(SETTINGS_FILE(), JSON.stringify(s, null, 2)); placesCache = null; }
function applySpellSettings() {
  const ses = session.defaultSession;
  const st = loadSettings();
  const avail = ses.availableSpellCheckerLanguages || [];
  let langs = (st.spellLangs || []).filter(l => avail.includes(l));
  if (!langs.length) langs = ['en-AU', 'en-GB', 'en-US'].filter(l => avail.includes(l)).slice(0, 1);
  try { if (langs.length) ses.setSpellCheckerLanguages(langs); } catch {}
  try { ses.setSpellCheckerEnabled(st.spellcheck !== false); } catch {}
}
ipcMain.handle('settings:get', () => loadSettings());
ipcMain.handle('settings:set', (_e, patch) => { const st = { ...loadSettings(), ...(patch || {}) }; saveSettings(st); return st; });
ipcMain.handle('settings:spell', () => {
  const ses = session.defaultSession;
  const st = loadSettings();
  return { available: ses.availableSpellCheckerLanguages || [], current: ses.getSpellCheckerLanguages(), enabled: st.spellcheck !== false };
});
ipcMain.handle('settings:setSpell', (_e, langs, enabled) => {
  const st = loadSettings();
  st.spellLangs = (langs || []).slice(0, 3);
  st.spellcheck = enabled !== false;
  saveSettings(st);
  applySpellSettings();
  return session.defaultSession.getSpellCheckerLanguages();
});
ipcMain.handle('spell:list', async () => { try { return await session.defaultSession.listWordsInSpellCheckerDictionary(); } catch { return []; } });
ipcMain.handle('spell:remove', (_e, word) => { try { return session.defaultSession.removeWordFromSpellCheckerDictionary(word); } catch { return false; } });

// ---------- Spellcheck: teach it the names from your character/place/item sheets ----------
ipcMain.handle('spell:add', (_e, words) => {
  const ses = win.webContents.session;
  for (const w of (words || []).slice(0, 2000)) { try { ses.addWordToSpellCheckerDictionary(String(w)); } catch {} }
  return true;
});

// ---------- Window ----------
ipcMain.handle('win:zoom', (e, f) => { const z = Math.min(1.5, Math.max(0.75, +f || 1)); e.sender.setZoomFactor(z); return z; });
ipcMain.handle('win:fullscreen', (_e, on) => { win.setFullScreen(!!on); return win.isFullScreen(); });

// ---------- Updates ----------
// The app checks a public GitHub repo that only holds update packages (the code itself lives in a private repo).
// An update replaces the app's own files (app/, main.js, preload.js, package.json), never your projects.
// Each package is checked against its SHA-256 fingerprint before anything is written.
const { net } = require('electron');
const crypto = require('crypto');
const zlib = require('zlib');
// Unwip's own address first (it never changes, whatever happens on GitHub), then GitHub under the account's name.
// Never add an address Unwip doesn't own: the newest version found anywhere is installed, so a lookalike address
// someone else could register (like the account's old name) would let them hand out a fake update.
const UPDATE_REPO = 'UnwipOfficial/unwip-releases', UPDATE_SITE = 'https://unwip.app/updates/';
// first a small manifest file in the repo (fast, no API limits), then GitHub's Releases list as a backup
// The releases repo is public, so updates need no key or account. (Earlier versions could hold a private GitHub
// "update key" in settings; it's no longer used, and it's removed from the settings file at start-up.)
const UPDATE_URLS = () => process.env.UNWIP_UPDATE_URL ? process.env.UNWIP_UPDATE_URL.split(",") : DEV ? [
  `${UPDATE_SITE}dev/latest.json`,
  `https://raw.githubusercontent.com/${UPDATE_REPO}/main/dev/latest.json`
] : [
  `${UPDATE_SITE}latest.json`,
  `https://raw.githubusercontent.com/${UPDATE_REPO}/main/latest.json`,
  `https://api.github.com/repos/${UPDATE_REPO}/releases/latest`
];
const assetURL = a => a.browser_download_url;
const UPDATE_TARGET = () => process.env.UNWIP_UPDATE_TARGET || app.getAppPath();
let updateState = { status: 'idle' };
const APP_VERSION = () => readJSON(path.join(__dirname, 'package.json'), {}).version || app.getVersion();   // idle | checking | none | downloading | ready | error

function versionNum(v) { return String(v || '0').replace(/^v/i, '').split(/[.-]/).slice(0, 3).map(n => parseInt(n, 10) || 0); }
function newer(a, b) { const x = versionNum(a), y = versionNum(b); for (let i = 0; i < 3; i++) { if (x[i] !== y[i]) return x[i] > y[i]; } return false; }

async function fetchBuf(url) {
  const headers = { 'User-Agent': 'Unwip-Updater', Accept: 'application/octet-stream, application/json' };
  const r = await net.fetch(url, { headers });
  if (!r.ok) throw new Error(`Download failed (${r.status})`);
  return Buffer.from(await r.arrayBuffer());
}
// minimal zip reader (stored + deflate), enough for our own update packages
function unzip(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('Not a zip file');
  const count = buf.readUInt16LE(eocd + 10); let p = buf.readUInt32LE(eocd + 16);
  const files = [];
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('Damaged zip');
    const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), nlen = buf.readUInt16LE(p + 28), xlen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32), off = buf.readUInt32LE(p + 42);
    const name = buf.slice(p + 46, p + 46 + nlen).toString('utf8');
    p += 46 + nlen + xlen + clen;
    if (name.endsWith('/')) continue;
    const lnlen = buf.readUInt16LE(off + 26), lxlen = buf.readUInt16LE(off + 28);
    const data = buf.slice(off + 30 + lnlen + lxlen, off + 30 + lnlen + lxlen + csize);
    files.push({ name, data: method === 0 ? data : method === 8 ? zlib.inflateRawSync(data) : (() => { throw new Error('Unsupported zip'); })() });
  }
  return files;
}
const ALLOWED = name => !name.includes('..') && !path.isAbsolute(name) && !name.includes('\\') && (/^app\/[\w\-./]+$/.test(name) || ['main.js', 'preload.js', 'package.json'].includes(name));

async function checkForUpdate() {
  updateState = { status: 'checking' };
  try {
    let rel = null, lastErr = null;
    // ask both places and take the newest: the quick copy can lag a few minutes behind a new release
    const found = await Promise.all(UPDATE_URLS().map(async url => {
      try { const j = JSON.parse((await fetchBuf(url + (url.includes('raw.githubusercontent') || url.startsWith(UPDATE_SITE) ? `?t=${Date.now()}` : ''))).toString('utf8')); return j && j.tag_name ? j : null; } catch (e) { lastErr = e; return null; }
    }));
    for (const j of found) if (j && (!rel || newer(String(j.tag_name).replace(/^v/i, ''), String(rel.tag_name).replace(/^v/i, '')))) rel = j;
    if (!rel) throw lastErr || new Error('No update information found');
    const version = String(rel.tag_name || '').replace(/^v/i, '');
    if (!version || !newer(version, APP_VERSION())) { updateState = { status: 'none', current: APP_VERSION() }; return updateState; }
    const zipA = (rel.assets || []).find(a => /\.zip$/i.test(a.name));
    const shaA = (rel.assets || []).find(a => /\.sha256$/i.test(a.name));
    if (!zipA) throw new Error('The update has no package');
    // and the package itself must come from Unwip's own places too
    const ours = u => typeof u === 'string' && (u.startsWith(`https://raw.githubusercontent.com/${UPDATE_REPO}/`) || u.startsWith(`https://github.com/${UPDATE_REPO}/`) || u.startsWith(UPDATE_SITE));
    if (!ours(assetURL(zipA)) || (shaA && !ours(assetURL(shaA)))) throw new Error('The update came from an unexpected place, so it was skipped');
    updateState = { status: 'available', version, notes: rel.body || '', zip: assetURL(zipA), sha: shaA ? assetURL(shaA) : null, shaInline: ((rel.body || '').match(/sha256:\s*([a-f0-9]{64})/i) || [])[1] || null };
    return updateState;
  } catch (e) { updateState = { status: 'error', error: String(e.message || e) }; return updateState; }
}

async function installUpdate() {
  if (updateState.status !== 'available') await checkForUpdate();
  if (updateState.status !== 'available') return updateState;
  const u = updateState;
  updateState = { ...u, status: 'downloading' };
  try {
    const zipBuf = await fetchBuf(u.zip);
    const want = (u.sha ? (await fetchBuf(u.sha)).toString('utf8') : u.shaInline || '').trim().split(/\s+/)[0].toLowerCase();
    const got = crypto.createHash('sha256').update(zipBuf).digest('hex');
    if (!/^[a-f0-9]{64}$/.test(want) || want !== got) throw new Error('The download didn’t match its fingerprint, so it wasn’t installed.');
    const files = unzip(zipBuf);
    if (!files.length || files.some(f => !ALLOWED(f.name))) throw new Error('The update package looks wrong, so it wasn’t installed.');
    const pkg = files.find(f => f.name === 'package.json');
    if (!pkg || !files.some(f => f.name === 'app/index.html') || !files.some(f => f.name === 'main.js')) throw new Error('The update package is incomplete.');
    const meta = JSON.parse(pkg.data.toString('utf8'));
    // a Dev package never goes into the real app, and the real one never into Dev
    if ((meta.flavor === 'dev' ? 'dev' : 'stable') !== FLAVOR) throw new Error(DEV ? 'That update is for the normal Unwip, not Unwip Dev, so it wasn’t installed.' : 'That update is a test (Dev) version, so it wasn’t installed.');
    if (meta.unwipMinElectron && newer(meta.unwipMinElectron, process.versions.electron)) throw new Error('This update needs the full installer (a newer engine). Download it from the Unwip page.');
    // a backup of the book that's open, before anything changes
    if (presenceSlug) { try { makeBackup(presenceSlug); } catch {} }
    // keep a copy of the current files, then write the new ones (each written safely: temp file, then rename)
    const target = UPDATE_TARGET();
    const backup = path.join(path.dirname(target), path.basename(target) + '-previous');
    fs.rmSync(backup, { recursive: true, force: true });
    fs.cpSync(target, backup, { recursive: true });
    try {
      for (const f of files) { const out = path.join(target, ...f.name.split('/')); ensureDir(path.dirname(out)); writeFileSafe(out, f.data); }
    } catch (e) {
      fs.cpSync(backup, target, { recursive: true, force: true });   // put everything back
      throw e;
    }
    const st = loadSettings(); st.justUpdated = { version: u.version, notes: u.notes, at: Date.now() }; saveSettings(st);
    updateState = { status: 'ready', version: u.version, notes: u.notes };
    return updateState;
  } catch (e) { updateState = { status: 'error', error: String(e.message || e) }; return updateState; }
}
ipcMain.handle('update:check', () => checkForUpdate());
ipcMain.handle('update:install', () => installUpdate());
ipcMain.handle('update:state', () => ({ ...updateState, current: APP_VERSION(), flavor: FLAVOR, auto: app.isPackaged || !!process.env.UNWIP_UPDATE_URL }));
ipcMain.handle('app:relaunch', () => { app.relaunch(); app.exit(0); });
// licence texts shown in About › Open-source licences (only these files can be read this way)
const LICENSE_FILES = /^(fonts\/OFL-[\w-]+\.txt|vendor\/WORDNET-LICENSE\.txt|vendor\/SETUP-NOTICES\.txt|LICENSES\.txt|vendor\/harper\/(LICENSE|README\.txt|THIRD-PARTY-NOTICES\.txt))$/;
ipcMain.handle('app:licenseText', (_e, rel) => { if (!LICENSE_FILES.test(String(rel))) return null; try { return fs.readFileSync(path.join(__dirname, 'app', rel), 'utf8'); } catch { return null; } });
const engineDir = () => [path.dirname(process.execPath), process.resourcesPath, path.join(__dirname, 'node_modules', 'electron', 'dist')].filter(Boolean).find(d => fs.existsSync(path.join(d, 'LICENSE'))) || path.dirname(process.execPath);
ipcMain.handle('app:engineLicenses', () => {
  const dir = engineDir(), read = f => { try { return fs.readFileSync(path.join(dir, f), 'utf8'); } catch { return null; } };
  return { electron: process.versions.electron, chrome: process.versions.chrome, license: read('LICENSE'), chromium: fs.existsSync(path.join(dir, 'LICENSES.chromium.html')) };
});
ipcMain.handle('app:openChromiumLicenses', () => shell.openPath(path.join(engineDir(), 'LICENSES.chromium.html')));


// ---------- Sync folders (Dropbox, OneDrive) ----------
function dropboxFolders() {
  const out = [];
  for (const base of [process.env.LOCALAPPDATA, process.env.APPDATA].filter(Boolean)) {
    const info = readJSON(path.join(base, 'Dropbox', 'info.json'), null);
    if (info) for (const k of ['personal', 'business']) if (info[k] && info[k].path && !out.includes(info[k].path)) out.push(info[k].path);
  }
  if (MAC) {
    // the Mac Dropbox app keeps its settings in ~/.dropbox; newer versions put the folder in ~/Library/CloudStorage
    const info = readJSON(path.join(app.getPath('home'), '.dropbox', 'info.json'), null);
    if (info) for (const k of ['personal', 'business']) if (info[k] && info[k].path && !out.includes(info[k].path)) out.push(info[k].path);
    const cs = path.join(app.getPath('home'), 'Library', 'CloudStorage');
    try { for (const d of fs.readdirSync(cs)) if (/^Dropbox/i.test(d) && !out.includes(path.join(cs, d))) out.push(path.join(cs, d)); } catch {}
  }
  const guess = path.join(app.getPath('home'), 'Dropbox');
  if (!out.length && fs.existsSync(guess)) out.push(guess);
  return out;
}
function oneDriveFolders() {
  const out = [process.env.OneDrive, process.env.OneDriveConsumer].filter(Boolean);
  if (MAC) { const cs = path.join(app.getPath('home'), 'Library', 'CloudStorage'); try { for (const d of fs.readdirSync(cs)) if (/^OneDrive/i.test(d)) out.push(path.join(cs, d)); } catch {} }
  return [...new Set(out)];
}
// iCloud Drive on a Mac (only when it's turned on)
function iCloudDrive() {
  if (!MAC) return null;
  const d = path.join(app.getPath('home'), 'Library', 'Mobile Documents', 'com~apple~CloudDocs');
  return fs.existsSync(d) ? d : null;
}
// a note Dropbox keeps in the library folder saying which folder layout the books use (written by the phone/iPad version)
ipcMain.handle('library:layout', () => readJSON(path.join(LIBRARY(), '.unwip-layout.json'), null));
ipcMain.handle('library:info', () => {
  const lib = LIBRARY();
  const places = [];
  for (const d of dropboxFolders()) {
    // Dropbox gives the phone/iPad version its own folder (Dropbox/Apps/Unwip). Once that exists, it's the place
    // to keep the library so PC and phone share the same books; otherwise a plain Dropbox/Unwip folder.
    const full = path.join(d, FOLDER), appDir = path.join(d, 'Apps', FOLDER);
    const old = path.join(appDir, FOLDER), shared = fs.existsSync(path.join(old)) && path.resolve(LIBRARY()).toLowerCase() === path.resolve(old).toLowerCase() ? old : appDir;
    if (fs.existsSync(appDir)) places.push({ kind: 'dropbox', label: 'Dropbox (shared with the phone and iPad)', path: shared, exists: fs.existsSync(shared), shared: true });
    if (!fs.existsSync(appDir) || fs.existsSync(full)) places.push({ kind: 'dropbox', label: fs.existsSync(appDir) ? `Dropbox › Unwip (${MAC ? 'Macs' : 'PCs'} only: the phone and iPad can't see it)` : 'Dropbox', path: full, exists: fs.existsSync(full), computersOnly: fs.existsSync(appDir) });
  }
  for (const o of oneDriveFolders()) if (!places.some(p => p.path === path.join(o, FOLDER))) places.push({ kind: 'onedrive', label: 'OneDrive', path: path.join(o, FOLDER), exists: fs.existsSync(path.join(o, FOLDER)) });
  if (MAC) { const ic = iCloudDrive(); if (ic) places.push({ kind: 'icloud', label: 'iCloud Drive', path: path.join(ic, FOLDER), exists: fs.existsSync(path.join(ic, FOLDER)) }); }
  places.push({ kind: 'default', label: `${HERE} only (Documents)`, path: DEFAULT_LIBRARY(), exists: fs.existsSync(DEFAULT_LIBRARY()) });
  const cur = path.resolve(lib).toLowerCase();
  const kind = (places.find(p => path.resolve(p.path).toLowerCase() === cur) || { kind: 'custom' }).kind;
  return { path: lib, kind, places, parentMissing: !fs.existsSync(path.dirname(lib)), device: require('os').hostname() };
});
ipcMain.handle('library:pick', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Choose where to keep your Unwip books', properties: ['openDirectory', 'createDirectory'] });
  if (r.canceled || !r.filePaths.length) return null;
  const p = r.filePaths[0];
  return path.basename(p).toLowerCase() === FOLDER.toLowerCase() ? p : path.join(p, FOLDER);
});
// Move (or merge) the whole library into another folder. Nothing is deleted: the old folder is renamed and kept.
ipcMain.handle('library:move', (_e, target) => {
  const from = path.resolve(LIBRARY()), to = path.resolve(String(target || ''));
  if (!target || from.toLowerCase() === to.toLowerCase()) return { ok: true, moved: 0, path: from };
  if (to.toLowerCase().startsWith(from.toLowerCase() + path.sep)) throw new Error('Pick a folder outside your current library.');
  ensureDir(to);
  let moved = 0, kept = 0;
  if (fs.existsSync(from)) {
    for (const d of fs.readdirSync(from, { withFileTypes: true })) {
      const src = path.join(from, d.name);
      let dest = path.join(to, d.name);
      if (fs.existsSync(dest)) {
        if (d.name === '_Play') { mergePlay(src, dest); continue; }
        const a = readJSON(path.join(src, 'project.json'), null), b = readJSON(path.join(dest, 'project.json'), null);
        if (a && b && a.created && a.created === b.created && (b.modified || 0) >= (a.modified || 0)) { kept++; continue; }   // same project, the synced copy is newer
        let n = 2; while (fs.existsSync(dest)) dest = path.join(to, `${d.name} (from ${require('os').hostname()}${n > 2 ? ' ' + n : ''})`), n++;
      }
      fs.cpSync(src, dest, { recursive: true });
      moved++;
    }
  }
  const st = loadSettings(); st.libraryPath = path.resolve(to) === path.resolve(DEFAULT_LIBRARY()) ? null : to; saveSettings(st);
  libraryOverride = st.libraryPath || null;
  // keep the old folder, renamed, as a safety copy
  let old = null;
  if (fs.existsSync(from) && moved + kept > 0) {
    old = from + ' (old copy)'; let n = 2; while (fs.existsSync(old)) old = `${from} (old copy ${n++})`;
    try { fs.renameSync(from, old); } catch { old = from; }
  }
  return { ok: true, moved, kept, path: to, old };
});
function mergePlay(src, dest) {
  const a = readJSON(path.join(src, 'play.json'), { pieces: [], days: {} }), b = readJSON(path.join(dest, 'play.json'), { pieces: [], days: {} });
  const ids = new Set((b.pieces || []).map(p => p.id));
  b.pieces = [...(b.pieces || []), ...(a.pieces || []).filter(p => !ids.has(p.id))];
  for (const [d, n] of Object.entries(a.days || {})) b.days[d] = Math.max(b.days[d] || 0, n);
  writeFileSafe(path.join(dest, 'play.json'), JSON.stringify(b, null, 2));
  const sp = path.join(src, 'pieces'); if (fs.existsSync(sp)) { const dp = ensureDir(path.join(dest, 'pieces')); for (const f of fs.readdirSync(sp)) if (!fs.existsSync(path.join(dp, f))) fs.copyFileSync(path.join(sp, f), path.join(dp, f)); }
}

// ---------- Working on two devices ----------
// While a project is open, a small "open on <device>" note sits in its folder (refreshed every minute),
// so another device opening the same project can warn first.
const deviceName = () => require('os').hostname().replace(/[^\w-]/g, '') || 'this-pc';
const presenceFile = slug => path.join(projectDir(slug), `.open-on-${deviceName()}.json`);
let presenceSlug = null;
app.on('before-quit', () => { if (presenceSlug) try { fs.rmSync(presenceFile(presenceSlug), { force: true }); } catch {} });
ipcMain.handle('project:presence', (_e, slug, on) => {
  if (on) presenceSlug = slug; else if (presenceSlug === slug) presenceSlug = null;   // a late "closed" for another book mustn't forget this one
  try { if (on) fs.writeFileSync(presenceFile(slug), JSON.stringify({ device: require('os').hostname(), at: Date.now() })); else fs.rmSync(presenceFile(slug), { force: true }); } catch {}
  return true;
});
ipcMain.handle('project:others', (_e, slug) => {
  const dir = projectDir(slug), mine = path.basename(presenceFile(slug));
  return fs.readdirSync(dir).filter(f => /^\.open-on-.+\.json$/.test(f) && f !== mine)
    .map(f => readJSON(path.join(dir, f), null)).filter(x => x && Date.now() - x.at < 90000);
});
// "Please close it there": a note in the project folder that the other device sees within seconds of Dropbox syncing it
const takeoverFile = slug => path.join(projectDir(slug), '.takeover.json');
ipcMain.handle('project:requestTakeover', (_e, slug, on) => {
  try { if (on) fs.writeFileSync(takeoverFile(slug), JSON.stringify({ by: require('os').hostname(), at: Date.now() })); else fs.rmSync(takeoverFile(slug), { force: true }); } catch {}
  return true;
});
ipcMain.handle('project:checkTakeover', (_e, slug) => {
  const t = readJSON(takeoverFile(slug), null);
  return t && t.by !== require('os').hostname() && Date.now() - t.at < 180000 ? t : null;
});
// what this computer last saw of each document (kept on this PC only), to highlight changes made elsewhere
const seenFile = (slug, id) => path.join(ensureDir(path.join(app.getPath('userData'), 'seen', safeId(slug.replace(/[^\w-]+/g, '_')))), safeId(id) + '.html');
ipcMain.handle('seen:load', (_e, slug, id) => { try { const f = seenFile(slug, id); return { html: fs.readFileSync(f, 'utf8'), at: fs.statSync(f).mtimeMs }; } catch { return null; } });
// a binder change from another device arrived while this one has its own still to save: keep the incoming one as a
// conflicted copy first (the compare window then offers both), so this device's save can't quietly replace it
ipcMain.handle('project:keepIncoming', (_e, slug) => {
  try {
    const full = path.join(projectDir(slug), 'project.json'); if (!fs.existsSync(full)) return false;
    const day = new Date().toISOString().slice(0, 10), base = full.slice(0, -5);
    let c = `${base} (another device's conflicted copy ${day}).json`, n = 2;
    while (fs.existsSync(c)) c = `${base} (another device's conflicted copy ${day} ${n++}).json`;
    fs.copyFileSync(full, c); return true;
  } catch { return false; }
});
ipcMain.handle('seen:save', (_e, slug, id, html) => { try { fs.writeFileSync(seenFile(slug, id), html); } catch {} return true; });
// Dropbox keeps both versions when two devices change the same file, as "name (DEVICE's conflicted copy DATE)".
const CONFLICT = /\s*\(([^()]*?)(?:['’]s)?\s*conflicted copy[^()]*\)/i;
ipcMain.handle('project:conflicts', (_e, slug) => {
  const dir = projectDir(slug), out = [];
  const scan = (sub, kind) => { const d = path.join(dir, sub); if (!fs.existsSync(d)) return; for (const f of fs.readdirSync(d)) { const m = CONFLICT.exec(f); if (!m) continue; out.push({ file: path.posix.join(sub, f), kind, device: m[1].trim() || 'another device', original: f.replace(CONFLICT, '') }); } };
  scan('.', 'project'); scan('docs', 'doc');
  return out.filter(c => c.kind === 'doc' ? /\.html$/.test(c.original) : c.original === 'project.json');
});
ipcMain.handle('project:readConflict', (_e, slug, file) => {
  const p = path.resolve(projectDir(slug), file);
  if (!p.startsWith(path.resolve(projectDir(slug))) || !CONFLICT.test(path.basename(p))) throw new Error('Bad file');
  return fs.readFileSync(p, 'utf8');
});
ipcMain.handle('project:archiveConflict', (_e, slug, file) => {
  const p = path.resolve(projectDir(slug), file);
  if (!p.startsWith(path.resolve(projectDir(slug))) || !CONFLICT.test(path.basename(p))) throw new Error('Bad file');
  const d = ensureDir(path.join(projectDir(slug), 'backups', 'sync-conflicts'));
  fs.renameSync(p, path.join(d, Date.now() + ' ' + path.basename(p)));
  return true;
});
// Notice when another device changes this project's files (Dropbox writing them in)
let watcher = null, watchTimers = {};
ipcMain.handle('project:watch', (_e, slug) => {
  try { if (watcher) watcher.close(); } catch {}
  watcher = null;
  if (!slug) return true;
  const dir = projectDir(slug);
  try {
    watcher = fs.watch(dir, { recursive: true }, (_ev, name) => {
      if (!name) return;
      const rel = String(name).replace(/\\/g, '/');
      if (!(rel === 'project.json' || /^docs\/[\w-]+\.html$/.test(rel))) return;
      clearTimeout(watchTimers[rel]);
      watchTimers[rel] = setTimeout(() => {
        const full = path.resolve(dir, rel);
        let data; try { data = fs.readFileSync(full); } catch { return; }
        if (written.get(full) === fingerprint(data)) return;   // our own save
        written.set(full, fingerprint(data));
        lastExternal[slug] = Date.now();
        if (win && !win.isDestroyed()) win.webContents.send('project:external', { slug, file: rel, id: rel.startsWith('docs/') ? rel.slice(5, -5) : null });
        const pw = rel.startsWith('docs/') && popouts.get(popKey(slug, rel.slice(5, -5))); if (pw && !pw.isDestroyed()) pw.webContents.send('project:external', { slug, file: rel, id: rel.slice(5, -5) });
      }, 900);
    });
  } catch {}
  return true;
});

// ---------- Sync status (PC): the Dropbox / OneDrive app does the syncing; Unwip shows where a book is, whether that
// app is running, when another device last changed the open book, and can look for changes right away ----------
const lastExternal = {};
let procCache = { at: 0, list: '' };
function runningApps() {
  if (MAC) {
    if (Date.now() - procCache.at < 30000) return Promise.resolve(procCache.list);
    return new Promise(res => require('child_process').execFile('/bin/ps', ['-Ax', '-o', 'comm='], { timeout: 8000 }, (err, out) => { if (err) return res(null); procCache = { at: Date.now(), list: String(out).toLowerCase() }; res(procCache.list); }));
  }
  if (process.platform !== 'win32') return Promise.resolve(null);
  if (Date.now() - procCache.at < 30000) return Promise.resolve(procCache.list);
  return new Promise(res => require('child_process').execFile('tasklist', ['/FO', 'CSV', '/NH'], { windowsHide: true, timeout: 8000 }, (err, out) => { if (err) return res(null); procCache = { at: Date.now(), list: String(out).toLowerCase() }; res(procCache.list); }));
}
ipcMain.handle('sync:status', async (_e, slug) => {
  let dir = null; try { dir = slug ? path.dirname(projectDir(slug)) : LIBRARY(); } catch {}
  const label = dir ? placeLabel(dir) : '';
  const provider = label === 'Dropbox' ? 'dropbox' : label === 'OneDrive' ? 'onedrive' : label === 'Google Drive' ? 'gdrive' : label === 'iCloud Drive' ? 'icloud' : 'none';
  const exe = { dropbox: 'dropbox.exe', onedrive: 'onedrive.exe', gdrive: 'googledrivefs.exe', icloud: 'iclouddrive.exe' }[provider];
  const list = exe ? await runningApps() : null;
  // on a Mac: the app's name inside the process list (iCloud Drive is part of macOS, so it's always there)
  const macApp = { dropbox: 'dropbox.app/', onedrive: 'onedrive.app/', gdrive: 'google drive.app/' }[provider];
  const running = list == null || !exe ? null : MAC ? (macApp ? list.includes(macApp) : null) : list.includes('"' + exe + '"');
  return { label, provider, running, lastExternal: (slug && lastExternal[slug]) || 0 };
});
// look through the open book now for anything another device changed (the same as the folder watcher, on demand)
ipcMain.handle('sync:check', (_e, slug) => {
  const dir = projectDir(slug); let found = 0;
  const files = ['project.json', ...fs.readdirSync(path.join(dir, 'docs')).filter(f => /^[\w-]+\.html$/.test(f)).map(f => 'docs/' + f)];
  for (const rel of files) {
    const full = path.resolve(dir, rel); let data; try { data = fs.readFileSync(full); } catch { continue; }
    const fp = fingerprint(data);
    if (!written.has(full)) { written.set(full, fp); continue; }       // never opened here: nothing to compare with
    if (written.get(full) === fp) continue;
    written.set(full, fp); found++; lastExternal[slug] = Date.now();
    if (win && !win.isDestroyed()) win.webContents.send('project:external', { slug, file: rel, id: rel.startsWith('docs/') ? rel.slice(5, -5) : null });
  }
  return found;
});

// ---------- Full backups (.unwip files) ----------
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(b) { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
function zipFiles(files) {   // [{name, data: Buffer}] -> Buffer (deflate)
  const parts = [], central = []; let off = 0;
  for (const f of files) {
    const name = Buffer.from(f.name, 'utf8'), comp = zlib.deflateRawSync(f.data), crc = crc32(f.data);
    const h = Buffer.alloc(30); h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0x0800, 6); h.writeUInt16LE(8, 8);
    h.writeUInt32LE(crc, 14); h.writeUInt32LE(comp.length, 18); h.writeUInt32LE(f.data.length, 22); h.writeUInt16LE(name.length, 26);
    parts.push(h, name, comp);
    const c = Buffer.alloc(46); c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0x0800, 8); c.writeUInt16LE(8, 10);
    c.writeUInt32LE(crc, 16); c.writeUInt32LE(comp.length, 20); c.writeUInt32LE(f.data.length, 24); c.writeUInt16LE(name.length, 28); c.writeUInt32LE(off, 42);
    central.push(c, name); off += 30 + name.length + comp.length;
  }
  const cen = Buffer.concat(central), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10); end.writeUInt32LE(cen.length, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat([...parts, cen, end]);
}
function projectArchive(slug) {
  const dir = projectDir(slug), files = [];
  const walk = (d, rel) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    const r = rel ? rel + '/' + e.name : e.name;
    if (e.isDirectory()) { if (!rel && e.name === 'backups') continue; walk(path.join(d, e.name), r); }
    else if (!/^\.open-on-|\.tmp$/.test(e.name) && !CONFLICT.test(e.name)) files.push({ name: r, data: fs.readFileSync(path.join(d, e.name)) });
  } };
  walk(dir, '');
  // fonts you imported into Unwip live with the app, not the book; they go along so a restore on another computer looks the same
  try { for (const f of fs.readdirSync(FONT_DIR())) if (/\.(ttf|otf|woff2?)$/i.test(f)) files.push({ name: '_fonts/' + f, data: fs.readFileSync(path.join(FONT_DIR(), f)) }); } catch {}
  return zipFiles(files);
}
const dateStamp = () => new Date().toLocaleDateString('en-CA');
ipcMain.handle('backup:export', async (_e, slug) => {
  const p = readJSON(path.join(projectDir(slug), 'project.json'), {});
  const r = await dialog.showSaveDialog(win, { title: 'Save a full backup', defaultPath: path.join(app.getPath('documents'), `${slugify(p.title || slug)} ${dateStamp()}.unwip`), filters: [{ name: 'Unwip backup', extensions: ['unwip'] }] });
  if (r.canceled || !r.filePath) return null;
  fs.writeFileSync(r.filePath, projectArchive(slug));
  return r.filePath;
});
function restoreArchive(buf, titleSuffix) {
  const files = unzip(buf);
  const pj = files.find(f => f.name === 'project.json');
  if (!pj) throw new Error('This isn’t an Unwip backup.');
  const project = JSON.parse(pj.data.toString('utf8'));
  project.title = (project.title || 'Restored book') + (titleSuffix || '');
  let base = slugify(project.title), slug = base, n = 2;
  while (fs.existsSync(path.join(LIBRARY(), slug))) slug = `${base} (${n++})`;
  const dir = ensureDir(projectDir(slug));
  for (const f of files) {
    if (f.name.includes('..') || path.isAbsolute(f.name)) continue;
    if (f.name.startsWith('_fonts/')) {   // imported fonts go back into Unwip's font folder, if they're not there already
      const name = path.basename(f.name), to = path.join(ensureDir(FONT_DIR()), name);
      if (/\.(ttf|otf|woff2?)$/i.test(name) && !fs.existsSync(to)) fs.writeFileSync(to, f.data);
      continue;
    }
    const out = path.join(dir, ...f.name.split('/')); ensureDir(path.dirname(out));
    fs.writeFileSync(out, f.name === 'project.json' ? JSON.stringify({ ...project, modified: Date.now() }, null, 2) : f.data);
  }
  ensureDir(path.join(dir, 'docs'));
  return slug;
}
ipcMain.handle('backup:importFile', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Restore from a backup file', properties: ['openFile'], filters: [{ name: 'Unwip backup', extensions: ['unwip', 'zip'] }] });
  if (r.canceled || !r.filePaths.length) return null;
  return restoreArchive(fs.readFileSync(r.filePaths[0]), ' (restored)');
});
ipcMain.handle('backup:list', (_e, slug) => {
  const bdir = path.join(projectDir(slug), 'backups');
  if (!fs.existsSync(bdir)) return [];
  return fs.readdirSync(bdir).filter(f => /^\d{4}-/.test(f)).sort().reverse().map(stamp => {
    const docs = path.join(bdir, stamp, 'docs'); let n = 0, size = 0;
    try { for (const f of fs.readdirSync(docs)) { n++; size += fs.statSync(path.join(docs, f)).size; } } catch {}
    const pj = readJSON(path.join(bdir, stamp, 'project.json'), {});
    return { stamp, docs: n, size, words: pj.totalWords || 0 };
  });
});
// restoring an automatic backup makes a separate copy of the project, so nothing current is overwritten
ipcMain.handle('backup:restore', (_e, slug, stamp) => {
  const dir = projectDir(slug), b = path.join(dir, 'backups', path.basename(String(stamp)));
  if (!fs.existsSync(path.join(b, 'project.json'))) throw new Error('That backup is missing.');
  const files = [{ name: 'project.json', data: fs.readFileSync(path.join(b, 'project.json')) }];
  for (const f of fs.readdirSync(path.join(b, 'docs'))) files.push({ name: 'docs/' + f, data: fs.readFileSync(path.join(b, 'docs', f)) });
  for (const md of [path.join(dir, 'backups', 'media'), path.join(dir, 'media')]) if (fs.existsSync(md)) for (const f of fs.readdirSync(md)) if (!files.some(x => x.name === 'media/' + f)) files.push({ name: 'media/' + f, data: fs.readFileSync(path.join(md, f)) });
  const d = new Date(stamp.slice(0, 10) + 'T' + stamp.slice(11, 19).replace(/-/g, ':') + 'Z');   // stamps are stored in UTC
  const when = isNaN(d) ? stamp.slice(0, 10) : `${d.toLocaleDateString('en-CA')} ${String(d.getHours()).padStart(2, '0')}.${String(d.getMinutes()).padStart(2, '0')}`;
  return restoreArchive(zipFiles(files), ` (backup ${when})`);
});
// Optional extra copy somewhere else (a USB stick, another drive, a different cloud): once a day per project, last 10 kept
function extraBackup(slug, force) {
  const st = loadSettings(); const to = st.extraBackupDir;
  if (!to || !fs.existsSync(to)) return null;
  const p = readJSON(path.join(projectDir(slug), 'project.json'), {});
  const prefix = slugify(p.title || slug) + ' ';
  // only this book's copies: its name, then just the date ("Book 2026-10-15.unwip"), so "Book 2 …" isn't counted as "Book"
  const isMine = f => f.startsWith(prefix) && /^\d{4}-\d{2}-\d{2}\.unwip$/.test(f.slice(prefix.length));
  const mine = fs.readdirSync(to).filter(isMine).sort();
  const todays = prefix + dateStamp() + '.unwip';
  if (!force && mine.includes(todays)) return null;
  try { fs.writeFileSync(path.join(to, todays), projectArchive(slug)); } catch { return null; }
  const all = fs.readdirSync(to).filter(isMine).sort();
  while (all.length > 10) { try { fs.rmSync(path.join(to, all.shift())); } catch { break; } }
  return todays;
}
ipcMain.handle('backup:extraPick', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Choose a folder for extra backup copies', properties: ['openDirectory', 'createDirectory'] });
  return r.canceled || !r.filePaths.length ? null : r.filePaths[0];
});
ipcMain.handle('backup:extraNow', (_e, slug) => extraBackup(slug, true));
